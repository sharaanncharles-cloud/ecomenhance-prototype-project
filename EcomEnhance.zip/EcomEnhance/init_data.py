from app import db
from models import User, Category, Product, Inventory, Discount
from datetime import datetime, timedelta
import logging

def init_sample_data():
    """Initialize sample data if database is empty"""
    try:
        # Skip if products already exist
        if Product.query.count() > 0:
            logging.info("Products already exist, skipping initialization")
            return
        
        logging.info("Initializing sample data...")
        
        # Create admin user if not exists
        if not User.query.filter_by(email='admin@anniejameszone.com').first():
            admin = User(
                username='admin@anniejameszone.com',
                email='admin@anniejameszone.com',
                full_name='Administrator',
                phone='9876543210',
                is_admin=True,
                is_verified=True
            )
            admin.set_password('Admin@123')
            db.session.add(admin)
        
        # Create sample regular user if not exists
        if not User.query.filter_by(email='customer@example.com').first():
            user = User(
                username='customer@example.com',
                email='customer@example.com',
                full_name='John Doe',
                phone='9876543211',
                is_verified=True
            )
            user.set_password('password123')
            db.session.add(user)
        
        # Create categories (with working image URLs)
        categories = [
            {'name': 'Shirts', 'description': 'Formal and casual shirts', 'image_url': 'https://images.unsplash.com/photo-1752084863113-b52a927a8571?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'T-Shirts', 'description': 'Comfortable cotton t-shirts', 'image_url': 'https://plus.unsplash.com/premium_photo-1718913936342-eaafff98834b?q=80&w=1172&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Jeans', 'description': 'Stylish denim jeans', 'image_url': 'https://images.unsplash.com/photo-1555689502-c4b22d76c56f?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Footwear', 'description': 'Shoes and sandals', 'image_url': 'https://plus.unsplash.com/premium_photo-1673367751742-c8bb4902be75?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Accessories', 'description': 'Belts, watches, and more', 'image_url': 'https://images.unsplash.com/photo-1664286074176-5206ee5dc878?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0'},
        ]
        
        category_objects = {}
        for cat_data in categories:
            category = Category(name=cat_data['name'], description=cat_data['description'], image_url=cat_data['image_url'])
            db.session.add(category)
            category_objects[cat_data['name']] = category
        
        db.session.flush()
        
        # Create products (with your provided image URLs)
        products = [
            {'name': 'Classic White Shirt', 'category': 'Shirts', 'price': 1299.00, 'discounted_price': 999.00,
             'description': 'Premium cotton white shirt perfect for formal occasions',
             'image_url': 'https://images.unsplash.com/photo-1752084863113-b52a927a8571?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Blue Denim Shirt', 'category': 'Shirts', 'price': 1499.00,
             'description': 'Stylish blue denim shirt for casual wear',
             'image_url': 'https://plus.unsplash.com/premium_photo-1727942420153-8573424d2a83?q=80&w=735&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Cotton T-Shirt', 'category': 'T-Shirts', 'price': 599.00, 'discounted_price': 449.00,
             'description': 'Comfortable 100% cotton t-shirt',
             'image_url': 'https://plus.unsplash.com/premium_photo-1718913936342-eaafff98834b?q=80&w=1172&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Graphic T-Shirt', 'category': 'T-Shirts', 'price': 699.00,
             'description': 'Trendy graphic print t-shirt',
             'image_url': 'https://images.unsplash.com/photo-1621446511130-0ed6519bfeb6?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Slim Fit Jeans', 'category': 'Jeans', 'price': 2199.00, 'discounted_price': 1799.00,
             'description': 'Modern slim fit denim jeans',
             'image_url': 'https://images.unsplash.com/photo-1555689502-c4b22d76c56f?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Regular Fit Jeans', 'category': 'Jeans', 'price': 1999.00,
             'description': 'Comfortable regular fit jeans',
             'image_url': 'https://images.unsplash.com/photo-1475178626620-a4d074967452?q=80&w=686&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Leather Formal Shoes', 'category': 'Footwear', 'price': 3499.00, 'discounted_price': 2799.00,
             'description': 'Premium leather formal shoes',
             'image_url': 'https://plus.unsplash.com/premium_photo-1673367751742-c8bb4902be75?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Casual Sneakers', 'category': 'Footwear', 'price': 2499.00,
             'description': 'Comfortable casual sneakers',
             'image_url': 'https://images.unsplash.com/photo-1582231640349-6ea6881fabeb?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Leather Belt', 'category': 'Accessories', 'price': 799.00, 'discounted_price': 599.00,
             'description': 'Genuine leather belt',
             'image_url': 'https://images.unsplash.com/photo-1664286074176-5206ee5dc878?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0'},
            {'name': 'Digital Watch', 'category': 'Accessories', 'price': 1599.00,
             'description': 'Stylish digital watch',
             'image_url': 'https://images.unsplash.com/photo-1626793167849-9d7c65d0932d?q=80&w=1025&auto=format&fit=crop&ixlib=rb-4.1.0'},
        ]
        
        for prod_data in products:
            product = Product(
                name=prod_data['name'],
                category_id=category_objects[prod_data['category']].id,
                price=prod_data['price'],
                discounted_price=prod_data.get('discounted_price'),
                description=prod_data['description'],
                image_url=prod_data['image_url'],
                featured=True if prod_data.get('discounted_price') else False
            )
            db.session.add(product)
            db.session.flush()
            
            sizes = ['S', 'M', 'L', 'XL'] if prod_data['category'] in ['Shirts', 'T-Shirts'] else \
                    ['28', '30', '32', '34', '36'] if prod_data['category'] == 'Jeans' else \
                    ['6', '7', '8', '9', '10'] if prod_data['category'] == 'Footwear' else \
                    ['One Size']
            for size in sizes:
                inventory = Inventory(product_id=product.id, size=size, quantity=25, reorder_level=5)
                db.session.add(inventory)
        
        # Create discounts if they don't exist
        discounts = [
            {'code': 'WELCOME10', 'description': 'Welcome discount for new customers', 'discount_type': 'percentage', 'discount_value': 10.0, 'min_order_amount': 500.0, 'valid_until': datetime.utcnow() + timedelta(days=30)},
            {'code': 'FLAT200', 'description': 'Flat ₹200 off on orders above ₹1500', 'discount_type': 'fixed', 'discount_value': 200.0, 'min_order_amount': 1500.0, 'valid_until': datetime.utcnow() + timedelta(days=15)},
            {'code': 'SAVE25', 'description': '25% off with maximum discount of ₹500', 'discount_type': 'percentage', 'discount_value': 25.0, 'min_order_amount': 1000.0, 'max_discount': 500.0, 'usage_limit': 100, 'valid_until': datetime.utcnow() + timedelta(days=7)}
        ]
        
        for disc_data in discounts:
            if not Discount.query.filter_by(code=disc_data['code']).first():
                discount = Discount(
                    code=disc_data['code'],
                    description=disc_data['description'],
                    discount_type=disc_data['discount_type'],
                    discount_value=disc_data['discount_value'],
                    min_order_amount=disc_data['min_order_amount'],
                    max_discount=disc_data.get('max_discount'),
                    usage_limit=disc_data.get('usage_limit'),
                    valid_until=disc_data['valid_until']
                )
                db.session.add(discount)
        
        db.session.commit()
        logging.info("Sample data initialized successfully!")
    
    except Exception as e:
        logging.error(f"Error initializing sample data: {str(e)}")
        db.session.rollback()
