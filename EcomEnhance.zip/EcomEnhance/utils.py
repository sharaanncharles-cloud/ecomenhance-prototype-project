import os
import requests
import logging
import razorpay
from datetime import datetime
from app import db
import pandas as pd
from sqlalchemy import func

# ⬇⬇ IMPORTANT: include all models used by exports
from models import (
    Discount, Order, OrderItem, User, Product, Category,
    Inventory, Return, Exchange, Feedback
)

def send_otp_email(email, otp):
    """Send OTP email using Brevo API with provided API key"""
    try:
        api_key = os.environ.get('BREVO_API_KEY', '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')
        url = "https://api.brevo.com/v3/smtp/email"
        headers = {
            'accept': 'application/json',
            'api-key': api_key,
            'content-type': 'application/json'
        }
        data = {
            'sender': {'name': 'Annie James Zone', 'email': 'charlessharaann@gmail.com'},
            'to': [{'email': email}],
            'subject': 'Password Reset OTP - Annie James Zone',
            'htmlContent': f'''
            <html>
                <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5;">
                    <div style="max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                        <div style="text-align: center; margin-bottom: 30px;">
                            <h1 style="color: #2c3e50; margin: 0;">Annie James Zone</h1>
                            <p style="color: #7f8c8d; margin: 5px 0 0 0;">Fashion & Style</p>
                        </div>
                        <h2 style="color: #34495e; margin-bottom: 20px;">Password Reset Request</h2>
                        <p style="color: #555; line-height: 1.6; margin-bottom: 25px;">
                            You requested to reset your password. Please use the OTP code below to proceed:
                        </p>
                        <div style="background-color: #ecf0f1; padding: 20px; text-align: center; border-radius: 8px; margin: 25px 0;">
                            <span style="font-size: 32px; font-weight: bold; color: #2c3e50; letter-spacing: 3px;">{otp}</span>
                        </div>
                        <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0;">
                            <p style="color: #856404; margin: 0; font-weight: bold;">⚠️ Important:</p>
                            <p style="color: #856404; margin: 5px 0 0 0;">This OTP will expire in 10 minutes for security reasons.</p>
                        </div>
                        <p style="color: #555; line-height: 1.6; margin-top: 25px;">
                            If you didn't request this password reset, please ignore this email and your password will remain unchanged.
                        </p>
                        <hr style="border: none; height: 1px; background-color: #ecf0f1; margin: 30px 0;">
                        <p style="color: #7f8c8d; font-size: 14px; text-align: center; margin: 0;">
                            © 2024 Annie James Zone. All rights reserved.<br>
                            This is an automated message, please do not reply to this email.
                        </p>
                    </div>
                </body>
            </html>
            '''
        }
        response = requests.post(url, json=data, headers=headers)
        logging.info(f"Brevo API Response Status: {response.status_code}")
        logging.info(f"Brevo API Response Body: {response.text}")
        return response.status_code == 201
    except Exception as e:
        logging.error(f"Error sending OTP email: {str(e)}")
        return False

def calculate_loyalty_points(order_amount):
    """1 point per ₹100 spent"""
    return int(order_amount / 100)

def validate_password(password):
    """Validate password criteria: 8-20 chars, 1 lower, 1 upper, 1 special, 1 number"""
    import re
    if len(password) < 8 or len(password) > 20:
        return False, "Password must be between 8 and 20 characters"
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number"
    if not re.search(r'[!@#$%^&*(),.?\":{}|<>]', password):
        return False, "Password must contain at least one special character"
    return True, "Valid password"

def create_razorpay_order(amount, currency='INR'):
    """Create a Razorpay order using provided API keys"""
    try:
        key_id = os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_dfgPVH8ltRmvRT')
        key_secret = os.environ.get('RAZORPAY_KEY_SECRET', '9AYC0S6SqBPCrxBNbGhGjfdZ')
        client = razorpay.Client(auth=(key_id, key_secret))
        order_data = {
            'amount': int(amount * 100),
            'currency': currency,
            'payment_capture': 1,
            'notes': {'store': 'Annie James Zone'}
        }
        order = client.order.create(data=order_data)
        logging.info(f"Razorpay order created: {order['id']}")
        return True, order
    except Exception as e:
        logging.error(f"Failed to create Razorpay order: {str(e)}")
        return False, None

def verify_razorpay_payment(payment_id, order_id, signature):
    """Verify Razorpay payment"""
    try:
        key_id = os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_dfgPVH8ltRmvRT')
        key_secret = os.environ.get('RAZORPAY_KEY_SECRET', '9AYC0S6SqBPCrxBNbGhGjfdZ')
        client = razorpay.Client(auth=(key_id, key_secret))
        params = {
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        }
        client.utility.verify_payment_signature(params)
        logging.info(f"Payment verified successfully: {payment_id}")
        return True
    except Exception as e:
        logging.error(f"Payment verification failed: {str(e)}")
        return False

def calculate_discount(discount_code, subtotal):
    """Calculate discount amount based on discount code"""
    discount = Discount.query.filter_by(code=discount_code, is_active=True).first()
    if not discount:
        return 0
    if discount.valid_until and discount.valid_until < datetime.utcnow():
        return 0
    if discount.usage_limit and discount.used_count >= discount.usage_limit:
        return 0
    if subtotal < discount.min_order_amount:
        return 0
    if discount.discount_type == 'percentage':
        amount = (subtotal * discount.discount_value) / 100
        if discount.max_discount:
            amount = min(amount, discount.max_discount)
    else:
        amount = discount.discount_value
    return amount

def apply_discount_code(discount_code, subtotal):
    """Apply discount code and update usage count"""
    discount = Discount.query.filter_by(code=discount_code, is_active=True).first()
    if not discount:
        return 0
    amount = calculate_discount(discount_code, subtotal)
    if amount > 0:
        discount.used_count += 1
        db.session.commit()
    return amount

def get_membership_benefits(tier):
    """Get membership benefits based on tier"""
    benefits = {
        'bronze': {'discount_percentage': 0,  'free_shipping_threshold': 2000, 'loyalty_multiplier': 1},
        'silver': {'discount_percentage': 5,  'free_shipping_threshold': 1500, 'loyalty_multiplier': 1.5},
        'gold':   {'discount_percentage': 10, 'free_shipping_threshold': 1000, 'loyalty_multiplier': 2},
        'platinum': {'discount_percentage': 15, 'free_shipping_threshold': 0, 'loyalty_multiplier': 3}
    }
    return benefits.get(tier, benefits['bronze'])

# =========================
#         EXPORTS
# =========================
def export_data_to_excel(data_type):
    """Export data to Excel file"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    
    if data_type == 'orders':

        orders_query = (

            db.session.query(

                Order.order_number.label('Order Number'),

                Order.created_at.label('Date'),

                User.full_name.label('Customer Name'),

                User.email.label('Email'),

                Order.total_amount.label('Total Amount'),

                Order.payment_method.label('Payment Method'),

                Order.payment_status.label('Payment Status'),

                Order.order_status.label('Order Status'),

                Order.tracking_number.label('Tracking Number'),

                Order.shipping_address.label('Shipping Address'),

                Product.name.label('Product Name'),

                OrderItem.size.label('Size'),

                OrderItem.quantity.label('Quantity'),

                OrderItem.price.label('Price per Unit')

            )

            .select_from(Order)

            .join(User, Order.user_id == User.id)

            .join(OrderItem, OrderItem.order_id == Order.id)

            .join(Product, OrderItem.product_id == Product.id)

            .order_by(Order.created_at.desc())

            .all()

        )

        orders_df = pd.DataFrame(orders_query, columns=[

            'Order Number', 'Date', 'Customer Name', 'Email',

            'Total Amount', 'Payment Method', 'Payment Status', 'Order Status',

            'Tracking Number', 'Shipping Address',

            'Product Name', 'Size', 'Quantity', 'Price per Unit'

        ])

        filename = f'orders_export_{timestamp}.xlsx'

        orders_df.to_excel(filename, index=False)


    elif data_type == 'customers':
        customers_query = (
            db.session.query(
                User.id.label('Customer ID'),
                User.full_name.label('Full Name'),
                User.email.label('Email'),
                User.phone.label('Phone'),
                User.city.label('City'),
                User.state.label('State'),
                User.loyalty_points.label('Loyalty Points'),
                User.membership_tier.label('Tier'),
                User.created_at.label('Join Date')
            )
            .filter(User.is_admin == False)
            .all()
        )
        customers_df = pd.DataFrame(customers_query, columns=[
            'Customer ID', 'Full Name', 'Email', 'Phone',
            'City', 'State', 'Loyalty Points', 'Tier', 'Join Date'
        ])
        filename = f'customers_export_{timestamp}.xlsx'
        customers_df.to_excel(filename, index=False)

    elif data_type == 'inventory':
        # Explicit joins to avoid ambiguity
        inventory_query = (
            db.session.query(
                Product.id.label('Product ID'),
                Product.name.label('Product Name'),
                Category.name.label('Category'),
                Product.price.label('Price'),
                Product.discounted_price.label('Discounted Price'),
                func.sum(func.coalesce(Inventory.quantity, 0)).label('Total Stock')
            )
            .select_from(Product)
            .join(Category, Product.category_id == Category.id)
            .outerjoin(Inventory, Inventory.product_id == Product.id)
            .group_by(
                Product.id, Product.name, Category.name,
                Product.price, Product.discounted_price
            )
            .all()
        )
        inventory_df = pd.DataFrame(inventory_query, columns=[
            'Product ID', 'Product Name', 'Category',
            'Price', 'Discounted Price', 'Total Stock'
        ])
        filename = f'inventory_export_{timestamp}.xlsx'
        inventory_df.to_excel(filename, index=False)

    elif data_type == 'sales':
        # Used by Analytics page's "Export Report" button
        sales_query = (
            db.session.query(
                Product.name.label('Product Name'),
                Category.name.label('Category'),
                func.sum(OrderItem.quantity).label('Units Sold'),
                func.sum(OrderItem.quantity * OrderItem.price).label('Revenue')
            )
            .select_from(OrderItem)
            .join(Product, OrderItem.product_id == Product.id)
            .join(Category, Product.category_id == Category.id)
            .join(Order, OrderItem.order_id == Order.id)
            .filter(Order.payment_status == 'completed')
            .group_by(Product.name, Category.name)
            .all()
        )
        sales_df = pd.DataFrame(sales_query, columns=[
            'Product Name', 'Category', 'Units Sold', 'Revenue'
        ])
        filename = f'sales_export_{timestamp}.xlsx'
        sales_df.to_excel(filename, index=False)

    elif data_type == 'analytics':
        # Alternate analytics export (same structure as sales)
        sales_query = (
            db.session.query(
                Product.name.label('Product Name'),
                Category.name.label('Category'),
                func.sum(OrderItem.quantity).label('Units Sold'),
                func.sum(OrderItem.quantity * OrderItem.price).label('Revenue')
            )
            .select_from(OrderItem)
            .join(Product, OrderItem.product_id == Product.id)
            .join(Category, Product.category_id == Category.id)
            .join(Order, OrderItem.order_id == Order.id)
            .filter(Order.payment_status == 'completed')
            .group_by(Product.name, Category.name)
            .all()
        )
        sales_df = pd.DataFrame(sales_query, columns=[
            'Product Name', 'Category', 'Units Sold', 'Revenue'
        ])
        filename = f'analytics_export_{timestamp}.xlsx'
        sales_df.to_excel(filename, index=False)

    elif data_type == 'discounts':
        discounts_query = (
            db.session.query(
                Discount.code.label('Code'),
                Discount.description.label('Description'),
                Discount.discount_type.label('Type'),
                Discount.discount_value.label('Value'),
                Discount.min_order_amount.label('Min Order Amount'),
                Discount.max_discount.label('Max Discount'),
                Discount.usage_limit.label('Usage Limit'),
                Discount.used_count.label('Used Count'),
                Discount.valid_from.label('Valid From'),
                Discount.valid_until.label('Valid Until'),
                Discount.is_active.label('Is Active')
            )
            .select_from(Discount)
            .all()
        )
        discounts_df = pd.DataFrame(discounts_query, columns=[
            'Code', 'Description', 'Type', 'Value', 'Min Order Amount',
            'Max Discount', 'Usage Limit', 'Used Count', 'Valid From',
            'Valid Until', 'Is Active'
        ])
        filename = f'discounts_export_{timestamp}.xlsx'
        discounts_df.to_excel(filename, index=False)

    elif data_type == 'returns':
        returns_query = (
            db.session.query(
                Return.id.label('Return ID'),
                User.full_name.label('Customer Name'),
                Order.order_number.label('Order Number'),
                Return.reason.label('Reason'),
                Return.status.label('Status'),
                Return.refund_amount.label('Refund Amount'),
                Return.created_at.label('Created At')
            )
            .select_from(Return)
            .join(User, Return.user_id == User.id)
            .join(Order, Return.order_id == Order.id)
            .all()
        )
        exchanges_query = (
            db.session.query(
                Exchange.id.label('Exchange ID'),
                User.full_name.label('Customer Name'),
                Order.order_number.label('Order Number'),
                Exchange.reason.label('Reason'),
                Exchange.status.label('Status'),
                Exchange.new_size.label('New Size'),
                Exchange.created_at.label('Created At')
            )
            .select_from(Exchange)
            .join(User, Exchange.user_id == User.id)
            .join(Order, Exchange.order_id == Order.id)
            .all()
        )
        returns_df = pd.DataFrame(returns_query, columns=[
            'Return ID', 'Customer Name', 'Order Number',
            'Reason', 'Status', 'Refund Amount', 'Created At'
        ])
        exchanges_df = pd.DataFrame(exchanges_query, columns=[
            'Exchange ID', 'Customer Name', 'Order Number',
            'Reason', 'Status', 'New Size', 'Created At'
        ])
        filename = f'returns_export_{timestamp}.xlsx'
        with pd.ExcelWriter(filename) as writer:
            returns_df.to_excel(writer, sheet_name='Returns', index=False)
            exchanges_df.to_excel(writer, sheet_name='Exchanges', index=False)

    elif data_type == 'feedback':
        feedback_query = (
            db.session.query(
                Feedback.id.label('Feedback ID'),
                User.full_name.label('Customer Name'),
                Product.name.label('Product Name'),
                Feedback.rating.label('Rating'),
                Feedback.title.label('Title'),
                Feedback.content.label('Content'),
                Feedback.is_verified_purchase.label('Verified Purchase'),
                Feedback.is_approved.label('Approved'),
                Feedback.created_at.label('Created At')
            )
            .select_from(Feedback)
            .join(User, Feedback.user_id == User.id)
            .outerjoin(Product, Feedback.product_id == Product.id)
            .all()
        )
        feedback_df = pd.DataFrame(feedback_query, columns=[
            'Feedback ID', 'Customer Name', 'Product Name', 'Rating', 'Title',
            'Content', 'Verified Purchase', 'Approved', 'Created At'
        ])
        filename = f'feedback_export_{timestamp}.xlsx'
        feedback_df.to_excel(filename, index=False)

    else:
        raise ValueError(f"Unknown data type: {data_type}")

    return filename

# =========================
#     OTHER UTILITIES
# =========================
def can_return_order(order):
    """Check if an order can be returned (within 2 days of created_at)"""
    from datetime import timedelta
    if order.order_status not in ['delivered']:
        return False
    return datetime.utcnow() <= order.created_at + timedelta(days=2)

def calculate_cod_charge(payment_method):
    """Fixed COD charge of ₹50 if payment method is COD"""
    if payment_method.lower() == 'cod':
        return 50.0
    return 0.0

def generate_cod_otp():
    """Generate 6-digit COD OTP"""
    import random
    return ''.join(random.choices('0123456789', k=6))

def send_cod_otp_sms(phone, otp):
    """Send COD OTP via SMS (placeholder)"""
    try:
        logging.info(f"COD OTP {otp} sent to {phone}")
        return True
    except Exception as e:
        logging.error(f"Failed to send COD OTP: {str(e)}")
        return False

def update_cod_delivery_status(order_id, status, notes=None):
    """Update COD delivery status and tracking"""
    try:
        order = Order.query.get(order_id)
        if not order:
            return False, "Order not found"
        if order.payment_method != 'cod':
            return False, "Not a COD order"

        if status == 'attempted':
            order.delivery_attempted = True
        elif status == 'delivered':
            order.order_status = 'delivered'
            order.payment_status = 'completed'
        elif status == 'failed':
            order.delivery_attempted = True
            order.cod_otp = generate_cod_otp()

        if notes:
            order.delivery_notes = notes

        order.updated_at = datetime.utcnow()
        db.session.commit()
        logging.info(f"COD delivery status updated for order {order.order_number}: {status}")
        return True, "Status updated successfully"
    except Exception as e:
        logging.error(f"Failed to update COD delivery status: {str(e)}")
        db.session.rollback()
        return False, str(e)

def get_razorpay_key_id():
    """Get Razorpay key ID for frontend"""
    return os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_dfgPVH8ltRmvRT')

def send_custom_email(recipient, subject, body):
    """Send a custom email using Brevo API"""
    try:
        api_key = os.environ.get('BREVO_API_KEY', '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')
        url = "https://api.brevo.com/v3/smtp/email"
        headers = {'accept': 'application/json', 'api-key': api_key, 'content-type': 'application/json'}
        data = {
            'sender': {'name': 'Annie James Zone', 'email': 'charlessharaann@gmail.com'},
            'to': [{'email': recipient}],
            'subject': subject,
            'htmlContent': f"<html><body style='font-family: Arial, sans-serif;'>{body}</body></html>"
        }
        response = requests.post(url, json=data, headers=headers)
        logging.info(f"Brevo API Response Status: {response.status_code}")
        logging.info(f"Brevo API Response Body: {response.text}")
        return response.status_code == 201
    except Exception as e:
        logging.error(f"Error sending custom email: {str(e)}")
        return False

import random
import string
from datetime import datetime

def generate_tracking_number():
    """Generate a unique tracking number in the format TRK-YYYYMMDD-XXXXX"""
    date_str = datetime.utcnow().strftime('%Y%m%d')
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"TRK-{date_str}-{random_part}"
