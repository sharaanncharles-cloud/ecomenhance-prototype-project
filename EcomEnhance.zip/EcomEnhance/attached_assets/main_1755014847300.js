// Annie James Zone - Main JavaScript File

// Global application object
const AJZ = {
    init: function() {
        this.initializeComponents();
        this.setupEventListeners();
        this.loadUserPreferences();
    },

    // Initialize Bootstrap components
    initializeComponents: function() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Initialize popovers
        const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        popoverTriggerList.map(function (popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });
    },

    // Setup event listeners
    setupEventListeners: function() {
        // Cart quantity updates
        this.setupCartListeners();
        
        // Search functionality
        this.setupSearchListeners();
        
        // Form validations
        this.setupFormValidations();
        
        // Image lazy loading
        this.setupLazyLoading();
        
        // Smooth scroll for anchor links
        this.setupSmoothScroll();
    },

    // Cart functionality
    setupCartListeners: function() {
        // Cart item quantity changes
        document.addEventListener('change', function(e) {
            if (e.target.matches('[name^="quantity_"]')) {
                const itemId = e.target.name.replace('quantity_', '');
                const quantity = parseInt(e.target.value);
                const price = parseFloat(e.target.dataset.price);
                
                // Update item total
                const totalElement = document.querySelector(`#total_${itemId}`);
                if (totalElement) {
                    totalElement.textContent = `₹${(price * quantity).toFixed(2)}`;
                }
                
                // Update cart total
                AJZ.updateCartTotal();
            }
        });

        // Add to cart buttons
        document.addEventListener('click', function(e) {
            if (e.target.matches('.add-to-cart-btn')) {
                e.preventDefault();
                const button = e.target;
                const originalText = button.textContent;
                
                // Show loading state
                button.innerHTML = '<span class="loading-spinner"></span> Adding...';
                button.disabled = true;
                
                // Submit form or make AJAX request here
                setTimeout(() => {
                    button.textContent = 'Added!';
                    button.classList.remove('btn-primary');
                    button.classList.add('btn-success');
                    
                    setTimeout(() => {
                        button.textContent = originalText;
                        button.classList.remove('btn-success');
                        button.classList.add('btn-primary');
                        button.disabled = false;
                    }, 1500);
                }, 1000);
            }
        });
    },

    // Update cart total
    updateCartTotal: function() {
        let total = 0;
        const quantityInputs = document.querySelectorAll('[name^="quantity_"]');
        
        quantityInputs.forEach(input => {
            const quantity = parseInt(input.value) || 0;
            const price = parseFloat(input.dataset.price) || 0;
            total += price * quantity;
        });

        const totalElements = document.querySelectorAll('.cart-total');
        totalElements.forEach(element => {
            element.textContent = `₹${total.toFixed(2)}`;
        });
    },

    // Search functionality
    setupSearchListeners: function() {
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            // Debounce search input
            let searchTimeout;
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    AJZ.performSearch(this.value);
                }, 300);
            });
        }

        // Search suggestions
        this.setupSearchSuggestions();
    },

    // Perform search
    performSearch: function(query) {
        if (query.length < 2) return;
        
        // In a real implementation, this would be an AJAX call
        console.log(`Searching for: ${query}`);
    },

    // Search suggestions
    setupSearchSuggestions: function() {
        const searchInput = document.querySelector('input[name="search"]');
        if (!searchInput) return;

        const suggestions = [
            'Shirts', 'T-Shirts', 'Jeans', 'Footwear', 'Accessories',
            'Formal Shirts', 'Casual Wear', 'Sneakers', 'Leather Shoes'
        ];

        // Create suggestions dropdown
        const suggestionsDiv = document.createElement('div');
        suggestionsDiv.className = 'search-suggestions position-absolute bg-dark border rounded shadow-lg';
        suggestionsDiv.style.display = 'none';
        suggestionsDiv.style.zIndex = '1000';
        suggestionsDiv.style.width = searchInput.offsetWidth + 'px';
        
        searchInput.parentNode.style.position = 'relative';
        searchInput.parentNode.appendChild(suggestionsDiv);

        searchInput.addEventListener('input', function() {
            const query = this.value.toLowerCase();
            if (query.length < 2) {
                suggestionsDiv.style.display = 'none';
                return;
            }

            const matches = suggestions.filter(item => 
                item.toLowerCase().includes(query)
            );

            if (matches.length > 0) {
                suggestionsDiv.innerHTML = matches.map(match => 
                    `<div class="suggestion-item p-2 text-light" style="cursor: pointer;">${match}</div>`
                ).join('');
                suggestionsDiv.style.display = 'block';
            } else {
                suggestionsDiv.style.display = 'none';
            }
        });

        // Handle suggestion clicks
        suggestionsDiv.addEventListener('click', function(e) {
            if (e.target.matches('.suggestion-item')) {
                searchInput.value = e.target.textContent;
                suggestionsDiv.style.display = 'none';
                // Submit search form
                searchInput.closest('form')?.submit();
            }
        });

        // Hide suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !suggestionsDiv.contains(e.target)) {
                suggestionsDiv.style.display = 'none';
            }
        });
    },

    // Form validations
    setupFormValidations: function() {
        // Password strength indicator
        const passwordInputs = document.querySelectorAll('input[type="password"]');
        passwordInputs.forEach(input => {
            if (input.name === 'password') {
                this.setupPasswordStrength(input);
            }
        });

        // Phone number formatting
        const phoneInputs = document.querySelectorAll('input[type="tel"]');
        phoneInputs.forEach(input => {
            input.addEventListener('input', this.formatPhoneNumber);
        });

        // Pincode validation
        const pincodeInputs = document.querySelectorAll('input[name*="pincode"]');
        pincodeInputs.forEach(input => {
            input.addEventListener('input', this.validatePincode);
        });

        // Email validation
        const emailInputs = document.querySelectorAll('input[type="email"]');
        emailInputs.forEach(input => {
            input.addEventListener('blur', this.validateEmail);
        });
    },

    // Password strength indicator
    setupPasswordStrength: function(input) {
        const strengthDiv = document.createElement('div');
        strengthDiv.className = 'password-strength mt-2';
        strengthDiv.innerHTML = `
            <div class="progress" style="height: 4px;">
                <div class="progress-bar" role="progressbar" style="width: 0%"></div>
            </div>
            <small class="text-muted">Password strength: <span class="strength-text">Weak</span></small>
        `;
        input.parentNode.appendChild(strengthDiv);

        input.addEventListener('input', function() {
            const password = this.value;
            const strength = AJZ.calculatePasswordStrength(password);
            const progressBar = strengthDiv.querySelector('.progress-bar');
            const strengthText = strengthDiv.querySelector('.strength-text');

            progressBar.style.width = `${strength.percentage}%`;
            progressBar.className = `progress-bar bg-${strength.color}`;
            strengthText.textContent = strength.text;
            strengthText.className = `text-${strength.color}`;
        });
    },

    // Calculate password strength
    calculatePasswordStrength: function(password) {
        let score = 0;
        if (password.length >= 8) score += 25;
        if (/[a-z]/.test(password)) score += 25;
        if (/[A-Z]/.test(password)) score += 25;
        if (/[0-9]/.test(password)) score += 25;
        if (/[^A-Za-z0-9]/.test(password)) score += 25;

        if (score <= 25) return { percentage: 25, color: 'danger', text: 'Weak' };
        if (score <= 50) return { percentage: 50, color: 'warning', text: 'Fair' };
        if (score <= 75) return { percentage: 75, color: 'info', text: 'Good' };
        return { percentage: 100, color: 'success', text: 'Strong' };
    },

    // Format phone number
    formatPhoneNumber: function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length <= 10) {
            if (value.length >= 6) {
                value = value.replace(/(\d{5})(\d{0,5})/, '$1-$2');
            }
            e.target.value = value;
        }
    },

    // Validate pincode
    validatePincode: function(e) {
        const pincode = e.target.value;
        const isValid = /^[0-9]{6}$/.test(pincode);
        
        if (pincode.length === 6 && !isValid) {
            e.target.setCustomValidity('Please enter a valid 6-digit pincode');
        } else {
            e.target.setCustomValidity('');
        }
    },

    // Validate email
    validateEmail: function(e) {
        const email = e.target.value;
        const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        
        if (email && !isValid) {
            e.target.setCustomValidity('Please enter a valid email address');
        } else {
            e.target.setCustomValidity('');
        }
    },

    // Setup lazy loading for images
    setupLazyLoading: function() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    },

    // Setup smooth scroll
    setupSmoothScroll: function() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    },

    // Load user preferences
    loadUserPreferences: function() {
        // Load saved preferences from localStorage
        const preferences = JSON.parse(localStorage.getItem('ajz_preferences') || '{}');
        
        // Apply theme preference
        if (preferences.theme) {
            document.documentElement.setAttribute('data-bs-theme', preferences.theme);
        }

        // Apply other preferences
        if (preferences.currency) {
            this.setCurrency(preferences.currency);
        }
    },

    // Save user preferences
    savePreference: function(key, value) {
        const preferences = JSON.parse(localStorage.getItem('ajz_preferences') || '{}');
        preferences[key] = value;
        localStorage.setItem('ajz_preferences', JSON.stringify(preferences));
    },

    // Currency formatting
    formatCurrency: function(amount, currency = '₹') {
        return `${currency}${amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    },

    // Show notification
    showNotification: function(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto dismiss
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
    },

    // Loading state management
    showLoading: function(element, text = 'Loading...') {
        const originalContent = element.innerHTML;
        element.setAttribute('data-original-content', originalContent);
        element.innerHTML = `<span class="loading-spinner"></span> ${text}`;
        element.disabled = true;
    },

    hideLoading: function(element) {
        const originalContent = element.getAttribute('data-original-content');
        if (originalContent) {
            element.innerHTML = originalContent;
            element.removeAttribute('data-original-content');
        }
        element.disabled = false;
    },

    // Utility functions
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    throttle: function(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }
};

// Shopping cart specific functions
const Cart = {
    // Add item to cart with animation
    addItem: function(productId, size, quantity = 1) {
        // Visual feedback
        const button = event.target;
        const originalText = button.textContent;
        
        AJZ.showLoading(button, 'Adding...');
        
        // Simulate API call
        setTimeout(() => {
            AJZ.hideLoading(button);
            button.textContent = 'Added!';
            button.classList.add('btn-success');
            
            // Show notification
            AJZ.showNotification('Item added to cart successfully!', 'success');
            
            // Reset button after 2 seconds
            setTimeout(() => {
                button.textContent = originalText;
                button.classList.remove('btn-success');
            }, 2000);
        }, 1000);
    },

    // Update cart badge
    updateBadge: function(count) {
        const badge = document.querySelector('.cart-badge');
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'inline' : 'none';
        }
    }
};

// Wishlist functions
const Wishlist = {
    toggle: function(productId) {
        const button = event.target.closest('button');
        const icon = button.querySelector('i');
        
        if (icon.classList.contains('fas')) {
            // Remove from wishlist
            icon.classList.remove('fas');
            icon.classList.add('far');
            button.classList.remove('btn-danger');
            button.classList.add('btn-outline-danger');
            AJZ.showNotification('Removed from wishlist', 'info');
        } else {
            // Add to wishlist
            icon.classList.remove('far');
            icon.classList.add('fas');
            button.classList.remove('btn-outline-danger');
            button.classList.add('btn-danger');
            AJZ.showNotification('Added to wishlist', 'success');
        }
    }
};

// Search functionality
const Search = {
    init: function() {
        const searchForm = document.querySelector('#search-form');
        if (searchForm) {
            searchForm.addEventListener('submit', this.handleSubmit);
        }

        const searchInput = document.querySelector('#search-input');
        if (searchInput) {
            searchInput.addEventListener('input', AJZ.debounce(this.handleInput, 300));
        }
    },

    handleSubmit: function(e) {
        e.preventDefault();
        const query = new FormData(e.target).get('search');
        if (query.trim()) {
            window.location.href = `/products?search=${encodeURIComponent(query)}`;
        }
    },

    handleInput: function(e) {
        const query = e.target.value;
        if (query.length >= 2) {
            Search.getSuggestions(query);
        }
    },

    getSuggestions: function(query) {
        // In a real implementation, this would fetch from an API
        const suggestions = [
            'Shirts', 'T-Shirts', 'Jeans', 'Footwear', 'Accessories'
        ].filter(item => item.toLowerCase().includes(query.toLowerCase()));
        
        this.displaySuggestions(suggestions);
    },

    displaySuggestions: function(suggestions) {
        // Implementation would show suggestions dropdown
        console.log('Suggestions:', suggestions);
    }
};

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    AJZ.init();
    Search.init();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // Page is hidden - pause any timers/animations
        console.log('Page hidden');
    } else {
        // Page is visible - resume timers/animations
        console.log('Page visible');
    }
});

// Handle online/offline status
window.addEventListener('online', function() {
    AJZ.showNotification('Connection restored', 'success');
});

window.addEventListener('offline', function() {
    AJZ.showNotification('Connection lost. Some features may not work.', 'warning', 5000);
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AJZ, Cart, Wishlist, Search };
}
