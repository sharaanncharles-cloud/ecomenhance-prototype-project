import os
import requests
import logging
import razorpay
from datetime import datetime
from models import Discount, Order, OrderItem, User, Product, Category
from app import db
import pandas as pd
from sqlalchemy import func

def send_otp_email(email, otp):
    """Send OTP email using Brevo API with provided API key"""
    try:
        # Use the provided Brevo API key
        api_key = os.environ.get('BREVO_API_KEY', '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')
        
        url = "https://api.brevo.com/v3/smtp/email"
        
        headers = {
            'accept': 'application/json',
            'api-key': api_key,
            'content-type': 'application/json'
        }
        
        data = {
            'sender': {
                'name': 'Annie James Zone',
                'email': 'charlessharaann@gmail.com'  # Verified sender from test file
            },
            'to': [{'email': email}],
            'subject': 'Password Reset OTP - Annie James Zone',
            'htmlContent': f'''
            <html>
                <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5;">
                    <div style="max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                        <div style="text-align: center; margin-bottom: 30px;">
                            <h1 style="color: #2c3e50; margin: 0;">Annie James Zone</h1>
                            <p style="color: #7f8c8d; margin: 5px 0 0 0;">Fashion & Style</p>
                        </div>
                        
                        <h2 style="color: #34495e; margin-bottom: 20px;">Password Reset Request</h2>
                        
                        <p style="color: #555; line-height: 1.6; margin-bottom: 25px;">
                            You requested to reset your password. Please use the OTP code below to proceed:
                        </p>
                        
                        <div style="background-color: #ecf0f1; padding: 20px; text-align: center; border-radius: 8px; margin: 25px 0;">
                            <span style="font-size: 32px; font-weight: bold; color: #2c3e50; letter-spacing: 3px;">{otp}</span>
                        </div>
                        
                        <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0;">
                            <p style="color: #856404; margin: 0; font-weight: bold;">⚠️ Important:</p>
                            <p style="color: #856404; margin: 5px 0 0 0;">This OTP will expire in 10 minutes for security reasons.</p>
                        </div>
                        
                        <p style="color: #555; line-height: 1.6; margin-top: 25px;">
                            If you didn't request this password reset, please ignore this email and your password will remain unchanged.
                        </p>
                        
                        <hr style="border: none; height: 1px; background-color: #ecf0f1; margin: 30px 0;">
                        
                        <p style="color: #7f8c8d; font-size: 14px; text-align: center; margin: 0;">
                            © 2024 Annie James Zone. All rights reserved.<br>
                            This is an automated message, please do not reply to this email.
                        </p>
                    </div>
                </body>
            </html>
            '''
        }
        
        response = requests.post(url, json=data, headers=headers)
        
        logging.info(f"Brevo API Response Status: {response.status_code}")
        logging.info(f"Brevo API Response Body: {response.text}")
        
        if response.status_code == 201:
            logging.info(f"OTP email sent successfully to {email}")
            return True
        else:
            logging.error(f"Failed to send OTP email: {response.text}")
            return False
            
    except Exception as e:
        logging.error(f"Error sending OTP email: {str(e)}")
        return False

def calculate_loyalty_points(order_amount):
    """Calculate loyalty points based on order amount"""
    # 1 point per 100 rupees spent
    return int(order_amount / 100)

def validate_password(password):
    """Validate password criteria: 8-20 chars, 1 lower, 1 upper, 1 special, 1 number"""
    import re
    
    if len(password) < 8 or len(password) > 20:
        return False, "Password must be between 8 and 20 characters"
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number"
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "Password must contain at least one special character"
    
    return True, "Valid password"

def create_razorpay_order(amount, currency='INR'):
    """Create a Razorpay order using provided API keys"""
    try:
        # Use the provided Razorpay credentials
        key_id = os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_awSHbTMJ7iSvgW')
        key_secret = os.environ.get('RAZORPAY_KEY_SECRET', 'your_razorpay_key_secret')
        
        client = razorpay.Client(auth=(key_id, key_secret))
        
        order_data = {
            'amount': int(amount * 100),  # Amount in paise
            'currency': currency,
            'payment_capture': 1,
            'notes': {
                'store': 'Annie James Zone'
            }
        }
        
        order = client.order.create(data=order_data)
        logging.info(f"Razorpay order created: {order['id']}")
        return True, order
        
    except Exception as e:
        logging.error(f"Failed to create Razorpay order: {str(e)}")
        return False, None

def verify_razorpay_payment(payment_id, order_id, signature):
    """Verify Razorpay payment"""
    try:
        key_id = os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_awSHbTMJ7iSvgW')
        key_secret = os.environ.get('RAZORPAY_KEY_SECRET', 'your_razorpay_key_secret')
        
        client = razorpay.Client(auth=(key_id, key_secret))
        
        params_dict = {
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        }
        
        client.utility.verify_payment_signature(params_dict)
        logging.info(f"Payment verified successfully: {payment_id}")
        return True
        
    except Exception as e:
        logging.error(f"Payment verification failed: {str(e)}")
        return False

def calculate_discount(discount_code, subtotal):
    """Calculate discount amount based on discount code"""
    discount = Discount.query.filter_by(code=discount_code, is_active=True).first()
    
    if not discount:
        return 0
    
    # Check if discount is valid
    if discount.valid_until and discount.valid_until < datetime.utcnow():
        return 0
    
    if discount.usage_limit and discount.used_count >= discount.usage_limit:
        return 0
    
    if subtotal < discount.min_order_amount:
        return 0
    
    # Calculate discount amount
    if discount.discount_type == 'percentage':
        discount_amount = (subtotal * discount.discount_value) / 100
        if discount.max_discount:
            discount_amount = min(discount_amount, discount.max_discount)
    else:  # fixed amount
        discount_amount = discount.discount_value
    
    return discount_amount

def apply_discount_code(discount_code, subtotal):
    """Apply discount code and update usage count"""
    discount = Discount.query.filter_by(code=discount_code, is_active=True).first()
    
    if not discount:
        return 0
    
    discount_amount = calculate_discount(discount_code, subtotal)
    
    if discount_amount > 0:
        # Update usage count
        discount.used_count += 1
        db.session.commit()
    
    return discount_amount

def get_membership_benefits(tier):
    """Get membership benefits based on tier"""
    benefits = {
        'bronze': {
            'discount_percentage': 0,
            'free_shipping_threshold': 2000,
            'loyalty_multiplier': 1
        },
        'silver': {
            'discount_percentage': 5,
            'free_shipping_threshold': 1500,
            'loyalty_multiplier': 1.5
        },
        'gold': {
            'discount_percentage': 10,
            'free_shipping_threshold': 1000,
            'loyalty_multiplier': 2
        },
        'platinum': {
            'discount_percentage': 15,
            'free_shipping_threshold': 0,
            'loyalty_multiplier': 3
        }
    }
    return benefits.get(tier, benefits['bronze'])

def export_data_to_excel(data_type):
    """Export data to Excel file"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    if data_type == 'orders':
        # Export orders data
        orders_query = db.session.query(
            Order.id,
            Order.created_at,
            User.full_name.label('customer_name'),
            User.email.label('customer_email'),
            Order.total_amount,
            Order.payment_method,
            Order.payment_status,
            Order.order_status
        ).join(User).all()
        
        orders_df = pd.DataFrame(orders_query, columns=[
            'Order ID', 'Date', 'Customer Name', 'Email', 
            'Amount', 'Payment Method', 'Payment Status', 'Order Status'
        ])
        
        filename = f'orders_export_{timestamp}.xlsx'
        orders_df.to_excel(filename, index=False)
        
    elif data_type == 'customers':
        # Export customers data
        customers_query = db.session.query(
            User.id,
            User.full_name,
            User.email,
            User.phone,
            User.city,
            User.state,
            User.loyalty_points,
            User.membership_tier,
            User.created_at
        ).filter_by(is_admin=False).all()
        
        customers_df = pd.DataFrame(customers_query, columns=[
            'Customer ID', 'Full Name', 'Email', 'Phone', 
            'City', 'State', 'Loyalty Points', 'Tier', 'Join Date'
        ])
        
        filename = f'customers_export_{timestamp}.xlsx'
        customers_df.to_excel(filename, index=False)
        
    elif data_type == 'inventory':
        # Export inventory data
        inventory_query = db.session.query(
            Product.id,
            Product.name,
            Category.name.label('category'),
            Product.price,
            Product.discounted_price,
            func.sum(func.coalesce(Inventory.quantity, 0)).label('total_stock')
        ).join(Category).outerjoin(Inventory).group_by(
            Product.id, Product.name, Category.name, 
            Product.price, Product.discounted_price
        ).all()
        
        inventory_df = pd.DataFrame(inventory_query, columns=[
            'Product ID', 'Product Name', 'Category', 
            'Price', 'Discounted Price', 'Total Stock'
        ])
        
        filename = f'inventory_export_{timestamp}.xlsx'
        inventory_df.to_excel(filename, index=False)
        
    elif data_type == 'sales':
        # Export sales data
        sales_query = db.session.query(
            Product.name.label('product_name'),
            Category.name.label('category'),
            func.sum(OrderItem.quantity).label('units_sold'),
            func.sum(OrderItem.quantity * OrderItem.price).label('revenue')
        ).join(Product).join(Category).join(Order).filter(
            Order.payment_status == 'completed'
        ).group_by(Product.name, Category.name).all()
        
        sales_df = pd.DataFrame(sales_query, columns=[
            'Product Name', 'Category', 'Units Sold', 'Revenue'
        ])
        
        filename = f'sales_export_{timestamp}.xlsx'
        sales_df.to_excel(filename, index=False)
        
    else:
        raise ValueError(f"Unknown data type: {data_type}")
    
    return filename

def can_return_order(order):
    """Check if an order can be returned (within 2 days)"""
    from datetime import timedelta
    
    if order.order_status not in ['delivered']:
        return False
    
    # Check if it's within 2 days of delivery
    # For now, using created_at as proxy for delivery date
    return datetime.utcnow() <= order.created_at + timedelta(days=2)

def calculate_cod_charge(payment_method):
    """Calculate COD charge"""
    return 99.0 if payment_method == 'COD' else 0.0
