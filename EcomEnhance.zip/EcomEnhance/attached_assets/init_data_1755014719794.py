from app import db
from models import Category, Product, Inventory, User, Discount
from datetime import datetime, timedelta

def init_sample_data():
    """Initialize sample data for the application"""
    
    # Check if data already exists to prevent duplicates
    if Category.query.first() is not None:
        return  # Data already exists
    
    # Create categories (fixed count to prevent duplicates)
    categories_data = [
        {'name': 'Shirts', 'description': 'Stylish shirts for all occasions'},
        {'name': 'T-Shirts', 'description': 'Comfortable and trendy t-shirts'},
        {'name': 'Jeans', 'description': 'Premium quality denim jeans'},
        {'name': 'Footwear', 'description': 'Shoes and sandals for every style'},
        {'name': 'Accessories', 'description': 'Fashion accessories and more'}
    ]
    
    categories = []
    for cat_data in categories_data:
        category = Category(name=cat_data['name'], description=cat_data['description'])
        db.session.add(category)
        categories.append(category)
    
    db.session.flush()  # Get category IDs
    
    # Create products (exactly 7 shirts, 3 footwear)
    products_data = [
        # Shirts (7 products)
        {'name': 'Classic White Shirt', 'description': 'Elegant white shirt perfect for formal occasions', 'price': 1299, 'discounted_price': 999, 'category': 'Shirts'},
        {'name': 'Casual Blue Shirt', 'description': 'Comfortable blue shirt for everyday wear', 'price': 899, 'discounted_price': 699, 'category': 'Shirts'},
        {'name': 'Striped Formal Shirt', 'description': 'Professional striped shirt for office wear', 'price': 1599, 'discounted_price': 1299, 'category': 'Shirts'},
        {'name': 'Checked Cotton Shirt', 'description': 'Trendy checked pattern cotton shirt', 'price': 1099, 'discounted_price': 899, 'category': 'Shirts'},
        {'name': 'Black Formal Shirt', 'description': 'Sophisticated black shirt for special events', 'price': 1399, 'discounted_price': 1199, 'category': 'Shirts'},
        {'name': 'Denim Shirt', 'description': 'Stylish denim shirt for casual outings', 'price': 1799, 'discounted_price': 1499, 'category': 'Shirts'},
        {'name': 'Printed Party Shirt', 'description': 'Vibrant printed shirt for parties and events', 'price': 1999, 'discounted_price': 1699, 'category': 'Shirts'},
        
        # T-Shirts
        {'name': 'Plain Cotton T-Shirt', 'description': 'Basic cotton t-shirt in multiple colors', 'price': 499, 'discounted_price': 399, 'category': 'T-Shirts'},
        {'name': 'Graphic Print Tee', 'description': 'Cool graphic printed t-shirt', 'price': 699, 'discounted_price': 599, 'category': 'T-Shirts'},
        {'name': 'V-Neck T-Shirt', 'description': 'Stylish v-neck t-shirt', 'price': 599, 'discounted_price': 499, 'category': 'T-Shirts'},
        
        # Jeans
        {'name': 'Slim Fit Jeans', 'description': 'Modern slim fit denim jeans', 'price': 2299, 'discounted_price': 1899, 'category': 'Jeans'},
        {'name': 'Regular Fit Jeans', 'description': 'Comfortable regular fit jeans', 'price': 1999, 'discounted_price': 1699, 'category': 'Jeans'},
        {'name': 'Distressed Jeans', 'description': 'Trendy distressed denim jeans', 'price': 2599, 'discounted_price': 2199, 'category': 'Jeans'},
        
        # Footwear (3 products)
        {'name': 'Casual Sneakers', 'description': 'Comfortable sneakers for daily wear', 'price': 2999, 'discounted_price': 2499, 'category': 'Footwear'},
        {'name': 'Formal Leather Shoes', 'description': 'Premium leather shoes for formal occasions', 'price': 4999, 'discounted_price': 4299, 'category': 'Footwear'},
        {'name': 'Sports Running Shoes', 'description': 'High-performance running shoes', 'price': 3999, 'discounted_price': 3499, 'category': 'Footwear'},
        
        # Accessories
        {'name': 'Leather Belt', 'description': 'Genuine leather belt', 'price': 899, 'discounted_price': 699, 'category': 'Accessories'},
        {'name': 'Sunglasses', 'description': 'Stylish UV protection sunglasses', 'price': 1299, 'discounted_price': 999, 'category': 'Accessories'},
    ]
    
    products = []
    category_map = {cat.name: cat.id for cat in categories}
    
    for prod_data in products_data:
        product = Product(
            name=prod_data['name'],
            description=prod_data['description'],
            price=prod_data['price'],
            discounted_price=prod_data['discounted_price'],
            category_id=category_map[prod_data['category']],
            image_url=f"https://via.placeholder.com/300x300?text={prod_data['name'].replace(' ', '+')}"
        )
        db.session.add(product)
        products.append(product)
    
    db.session.flush()  # Get product IDs
    
    # Create inventory for each product
    sizes = ['XS', 'S', 'M', 'L', 'XL']
    for product in products:
        for size in sizes:
            inventory = Inventory(
                product_id=product.id,
                size=size,
                quantity=50  # Start with 50 units per size
            )
            db.session.add(inventory)
    
    # Create admin user
    admin = User(
        username='admin',
        email='admin@anniejaneszone.com',
        full_name='Annie James Admin',
        phone='+91 9880171196',
        is_admin=True,
        admin_level='super_admin',
        is_verified=True
    )
    admin.set_password('Admin@123')
    db.session.add(admin)
    
    # Create sample discount codes
    discounts_data = [
        {
            'code': 'WELCOME10',
            'description': 'Welcome discount for new customers',
            'discount_type': 'percentage',
            'discount_value': 10.0,
            'min_order_amount': 999.0,
            'max_discount': 500.0,
            'usage_limit': 100,
            'valid_until': datetime.utcnow() + timedelta(days=30)
        },
        {
            'code': 'FLAT200',
            'description': 'Flat Rs. 200 off on orders above Rs. 1999',
            'discount_type': 'fixed',
            'discount_value': 200.0,
            'min_order_amount': 1999.0,
            'usage_limit': 50,
            'valid_until': datetime.utcnow() + timedelta(days=15)
        },
        {
            'code': 'BIGDEAL25',
            'description': '25% off on orders above Rs. 2999',
            'discount_type': 'percentage',
            'discount_value': 25.0,
            'min_order_amount': 2999.0,
            'max_discount': 1000.0,
            'usage_limit': 25,
            'valid_until': datetime.utcnow() + timedelta(days=7)
        }
    ]
    
    for disc_data in discounts_data:
        discount = Discount(**disc_data)
        db.session.add(discount)
    
    try:
        db.session.commit()
        print("Sample data initialized successfully!")
    except Exception as e:
        db.session.rollback()
        print(f"Error initializing sample data: {e}")
