import os
import random
import string
from datetime import datetime, timedelta
from flask import render_template, request, redirect, url_for, flash, jsonify, session, make_response
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import (User, Product, Category, Inventory, Order, OrderItem, 
                   CartItem, WishlistItem, Comment, Like, Discount, OTPVerification,
                   Return, Exchange)
from utils import (send_otp_email, calculate_loyalty_points, calculate_discount, 
                  validate_password, create_razorpay_order, verify_razorpay_payment, 
                  export_data_to_excel, can_return_order, calculate_cod_charge, apply_discount_code)
from sqlalchemy import func, extract
import json

@app.route('/')
def index():
    featured_products = Product.query.filter_by(is_active=True).limit(8).all()
    categories = Category.query.all()
    return render_template('index.html', products=featured_products, categories=categories)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.form
        
        # Validate password
        is_valid, message = validate_password(data['password'])
        if not is_valid:
            flash(message, 'danger')
            return redirect(url_for('register'))
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
        
        # Create user directly without OTP verification
        user = User()
        user.username = data['email']  # Use email as username
        user.email = data['email']
        user.full_name = data['full_name']
        user.phone = data['phone']
        user.is_verified = True  # Skip OTP verification
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/verify_otp/<purpose>', methods=['GET', 'POST'])
def verify_otp(purpose):
    if request.method == 'POST':
        otp = request.form['otp']
        
        if purpose == 'password_reset':
            email = session.get('reset_email')
            if not email:
                flash('Session expired. Please try again.', 'danger')
                return redirect(url_for('forgot_password'))
            
            # Check OTP and expiration (10 minutes)
            otp_record = OTPVerification.query.filter_by(
                email=email, otp=otp, purpose='password_reset', is_used=False
            ).first()
            
            if otp_record and otp_record.created_at > datetime.utcnow() - timedelta(minutes=10):
                otp_record.is_used = True
                db.session.commit()
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid or expired OTP. OTP expires after 10 minutes.', 'danger')
    
    return render_template('verify_otp.html', purpose=purpose)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check both email and username for login compatibility
        user = User.query.filter((User.email == username) | (User.username == username)).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Generate and send OTP
            otp = ''.join(random.choices(string.digits, k=6))
            
            otp_record = OTPVerification()
            otp_record.email = email
            otp_record.otp = otp
            otp_record.purpose = 'password_reset'
            db.session.add(otp_record)
            db.session.commit()
            
            session['reset_email'] = email
            
            if send_otp_email(email, otp):
                flash('OTP sent to your email. Please verify within 10 minutes.', 'info')
                return redirect(url_for('verify_otp', purpose='password_reset'))
            else:
                flash('Failed to send OTP. Please try again.', 'danger')
        else:
            flash('Email not found', 'danger')
    
    return render_template('forgot_password.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    email = session.get('reset_email')
    if not email:
        flash('Session expired. Please try again.', 'danger')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('reset_password.html')
        
        # Validate password
        is_valid, message = validate_password(password)
        if not is_valid:
            flash(message, 'danger')
            return render_template('reset_password.html')
        
        user = User.query.filter_by(email=email).first()
        if user:
            user.set_password(password)
            db.session.commit()
            session.pop('reset_email', None)
            flash('Password reset successful! Please login.', 'success')
            return redirect(url_for('login'))
    
    return render_template('reset_password.html')

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        # Update profile information
        current_user.full_name = request.form.get('full_name', current_user.full_name)
        current_user.phone = request.form.get('phone', current_user.phone)
        current_user.house_number = request.form.get('house_number', current_user.house_number)
        current_user.locality = request.form.get('locality', current_user.locality)
        current_user.apartment_name = request.form.get('apartment_name', current_user.apartment_name)
        current_user.landmark = request.form.get('landmark', current_user.landmark)
        current_user.street_name = request.form.get('street_name', current_user.street_name)
        current_user.city = request.form.get('city', current_user.city)
        current_user.state = request.form.get('state', current_user.state)
        current_user.pincode = request.form.get('pincode', current_user.pincode)
        
        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))
    
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('profile.html', orders=orders)

@app.route('/products')
def products():
    category_id = request.args.get('category', type=int)
    search = request.args.get('search', '')
    
    query = Product.query.filter_by(is_active=True)
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if search:
        query = query.filter(Product.name.ilike(f'%{search}%'))
    
    products = query.all()
    categories = Category.query.all()
    
    return render_template('products.html', products=products, categories=categories, 
                         selected_category=category_id, search=search)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    comments = Comment.query.filter_by(product_id=product_id).order_by(Comment.created_at.desc()).all()
    sizes = [inv.size for inv in product.inventory if inv.quantity > 0]
    
    # Check if user has liked this product
    user_liked = False
    if current_user.is_authenticated:
        user_liked = Like.query.filter_by(user_id=current_user.id, product_id=product_id).first() is not None
    
    return render_template('product_detail.html', product=product, comments=comments, 
                         sizes=sizes, user_liked=user_liked)

@app.route('/buy_now', methods=['POST'])
@login_required
def buy_now():
    """Direct buy now functionality - bypass cart"""
    product_id = request.form.get('product_id', type=int)
    size = request.form.get('size')
    quantity = request.form.get('quantity', 1, type=int)
    
    product = Product.query.get_or_404(product_id)
    
    # Check stock availability
    inventory = Inventory.query.filter_by(product_id=product_id, size=size).first()
    if not inventory or inventory.quantity < quantity:
        flash('Insufficient stock for the selected size', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))
    
    # Store buy now data in session
    session['buy_now_data'] = {
        'product_id': product_id,
        'size': size,
        'quantity': quantity,
        'price': product.get_price()
    }
    
    return redirect(url_for('checkout'))

@app.route('/add_to_cart', methods=['POST'])
@login_required
def add_to_cart():
    product_id = request.form.get('product_id', type=int)
    size = request.form.get('size')
    quantity = request.form.get('quantity', 1, type=int)
    
    # Check if item already in cart
    existing_item = CartItem.query.filter_by(
        user_id=current_user.id, product_id=product_id, size=size
    ).first()
    
    if existing_item:
        existing_item.quantity += quantity
    else:
        cart_item = CartItem()
        cart_item.user_id = current_user.id
        cart_item.product_id = product_id
        cart_item.size = size
        cart_item.quantity = quantity
        db.session.add(cart_item)
    
    db.session.commit()
    flash('Item added to cart', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/cart')
@login_required
def cart():
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    total = sum(item.product.get_price() * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@app.route('/remove_from_cart/<int:item_id>')
@login_required
def remove_from_cart(item_id):
    item = CartItem.query.get_or_404(item_id)
    if item.user_id == current_user.id:
        db.session.delete(item)
        db.session.commit()
        flash('Item removed from cart', 'info')
    return redirect(url_for('cart'))

@app.route('/update_cart', methods=['POST'])
@login_required
def update_cart():
    for key, value in request.form.items():
        if key.startswith('quantity_'):
            item_id = int(key.replace('quantity_', ''))
            quantity = int(value) if value else 0
            
            item = CartItem.query.get(item_id)
            if item and item.user_id == current_user.id:
                if quantity > 0:
                    item.quantity = quantity
                else:
                    db.session.delete(item)
    
    db.session.commit()
    flash('Cart updated', 'success')
    return redirect(url_for('cart'))

@app.route('/wishlist')
@login_required
def wishlist():
    wishlist_items = WishlistItem.query.filter_by(user_id=current_user.id).all()
    return render_template('wishlist.html', wishlist_items=wishlist_items)

@app.route('/add_to_wishlist/<int:product_id>')
@login_required
def add_to_wishlist(product_id):
    existing_item = WishlistItem.query.filter_by(
        user_id=current_user.id, product_id=product_id
    ).first()
    
    if not existing_item:
        wishlist_item = WishlistItem()
        wishlist_item.user_id = current_user.id
        wishlist_item.product_id = product_id
        db.session.add(wishlist_item)
        db.session.commit()
        flash('Item added to wishlist', 'success')
    else:
        flash('Item already in wishlist', 'info')
    
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/remove_from_wishlist/<int:item_id>')
@login_required
def remove_from_wishlist(item_id):
    item = WishlistItem.query.get_or_404(item_id)
    if item.user_id == current_user.id:
        db.session.delete(item)
        db.session.commit()
        flash('Item removed from wishlist', 'info')
    return redirect(url_for('wishlist'))

@app.route('/like_product/<int:product_id>')
@login_required
def like_product(product_id):
    existing_like = Like.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    
    if existing_like:
        db.session.delete(existing_like)
        liked = False
    else:
        like = Like()
        like.user_id = current_user.id
        like.product_id = product_id
        db.session.add(like)
        liked = True
    
    db.session.commit()
    
    if request.headers.get('Content-Type') == 'application/json':
        return jsonify({'liked': liked, 'likes_count': Product.query.get(product_id).get_likes_count()})
    
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    # Check if this is a buy now checkout or cart checkout
    buy_now_data = session.get('buy_now_data')
    
    if buy_now_data:
        # Buy now checkout
        product = Product.query.get(buy_now_data['product_id'])
        items = [{
            'product': product,
            'quantity': buy_now_data['quantity'],
            'size': buy_now_data['size'],
            'price': buy_now_data['price']
        }]
        subtotal = buy_now_data['price'] * buy_now_data['quantity']
    else:
        # Cart checkout
        cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
        if not cart_items:
            flash('Your cart is empty', 'warning')
            return redirect(url_for('cart'))
        
        items = [{
            'product': item.product,
            'quantity': item.quantity,
            'size': item.size,
            'price': item.product.get_price()
        } for item in cart_items]
        subtotal = sum(item['price'] * item['quantity'] for item in items)
    
    if request.method == 'POST':
        # Process checkout
        payment_method = request.form.get('payment_method')
        discount_code = request.form.get('discount_code', '').strip()
        
        # Calculate discount
        discount_amount = 0
        if discount_code:
            discount_amount = apply_discount_code(discount_code, subtotal)
        
        # Calculate COD charge
        cod_charge = calculate_cod_charge(payment_method)
        
        # Calculate total
        total_amount = subtotal - discount_amount + cod_charge
        
        if payment_method == 'Razorpay':
            # Create Razorpay order
            success, razorpay_order = create_razorpay_order(total_amount)
            if not success:
                flash('Failed to create payment order. Please try again.', 'danger')
                return render_template('checkout.html', items=items, subtotal=subtotal)
            
            # Store order data in session for payment completion
            session['pending_order'] = {
                'items': items,
                'subtotal': subtotal,
                'discount_amount': discount_amount,
                'cod_charge': cod_charge,
                'total_amount': total_amount,
                'payment_method': payment_method,
                'razorpay_order_id': razorpay_order['id'],
                'shipping_data': {
                    'house_number': request.form.get('house_number'),
                    'locality': request.form.get('locality'),
                    'apartment_name': request.form.get('apartment_name'),
                    'landmark': request.form.get('landmark'),
                    'street_name': request.form.get('street_name'),
                    'city': request.form.get('city'),
                    'state': request.form.get('state'),
                    'pincode': request.form.get('pincode')
                }
            }
            
            return render_template('checkout.html', 
                                 items=items, 
                                 subtotal=subtotal,
                                 discount_amount=discount_amount,
                                 cod_charge=cod_charge,
                                 total=total_amount,
                                 payment_method=payment_method,
                                 razorpay_order=razorpay_order,
                                 razorpay_key_id=os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_awSHbTMJ7iSvgW'))
        
        else:  # COD
            # Create order directly
            order = Order()
            order.user_id = current_user.id
            order.total_amount = total_amount
            order.discount_amount = discount_amount
            order.cod_charge = cod_charge
            order.payment_method = payment_method
            order.payment_status = 'pending'
            order.order_status = 'placed'
            
            # Set shipping address
            order.shipping_house_number = request.form.get('house_number')
            order.shipping_locality = request.form.get('locality')
            order.shipping_apartment_name = request.form.get('apartment_name')
            order.shipping_landmark = request.form.get('landmark')
            order.shipping_street_name = request.form.get('street_name')
            order.shipping_city = request.form.get('city')
            order.shipping_state = request.form.get('state')
            order.shipping_pincode = request.form.get('pincode')
            
            db.session.add(order)
            db.session.flush()  # Get order ID
            
            # Add order items
            for item in items:
                order_item = OrderItem()
                order_item.order_id = order.id
                order_item.product_id = item['product'].id
                order_item.quantity = item['quantity']
                order_item.size = item['size']
                order_item.price = item['price']
                db.session.add(order_item)
                
                # Update inventory
                inventory = Inventory.query.filter_by(
                    product_id=item['product'].id, 
                    size=item['size']
                ).first()
                if inventory:
                    inventory.quantity -= item['quantity']
            
            # Clear cart or buy now session
            if buy_now_data:
                session.pop('buy_now_data', None)
            else:
                CartItem.query.filter_by(user_id=current_user.id).delete()
            
            # Award loyalty points
            points = calculate_loyalty_points(total_amount)
            current_user.loyalty_points += points
            
            db.session.commit()
            
            flash('Order placed successfully!', 'success')
            return redirect(url_for('order_confirmation', order_id=order.id))
    
    return render_template('checkout.html', items=items, subtotal=subtotal)

@app.route('/payment_success', methods=['POST'])
@login_required
def payment_success():
    """Handle successful Razorpay payment"""
    try:
        # Get payment details
        payment_id = request.form.get('razorpay_payment_id')
        order_id = request.form.get('razorpay_order_id')
        signature = request.form.get('razorpay_signature')
        
        # Verify payment
        if not verify_razorpay_payment(payment_id, order_id, signature):
            flash('Payment verification failed', 'danger')
            return redirect(url_for('checkout'))
        
        # Get pending order data
        pending_order = session.get('pending_order')
        if not pending_order:
            flash('Order data not found', 'danger')
            return redirect(url_for('checkout'))
        
        # Create order
        order = Order()
        order.user_id = current_user.id
        order.total_amount = pending_order['total_amount']
        order.discount_amount = pending_order['discount_amount']
        order.cod_charge = pending_order['cod_charge']
        order.payment_method = pending_order['payment_method']
        order.payment_status = 'completed'
        order.payment_id = payment_id
        order.razorpay_order_id = order_id
        order.order_status = 'confirmed'
        
        # Set shipping address
        shipping = pending_order['shipping_data']
        order.shipping_house_number = shipping['house_number']
        order.shipping_locality = shipping['locality']
        order.shipping_apartment_name = shipping['apartment_name']
        order.shipping_landmark = shipping['landmark']
        order.shipping_street_name = shipping['street_name']
        order.shipping_city = shipping['city']
        order.shipping_state = shipping['state']
        order.shipping_pincode = shipping['pincode']
        
        db.session.add(order)
        db.session.flush()  # Get order ID
        
        # Add order items
        for item in pending_order['items']:
            order_item = OrderItem()
            order_item.order_id = order.id
            order_item.product_id = item['product']['id'] if isinstance(item['product'], dict) else item['product'].id
            order_item.quantity = item['quantity']
            order_item.size = item['size']
            order_item.price = item['price']
            db.session.add(order_item)
            
            # Update inventory
            product_id = item['product']['id'] if isinstance(item['product'], dict) else item['product'].id
            inventory = Inventory.query.filter_by(
                product_id=product_id, 
                size=item['size']
            ).first()
            if inventory:
                inventory.quantity -= item['quantity']
        
        # Clear cart or buy now session
        buy_now_data = session.get('buy_now_data')
        if buy_now_data:
            session.pop('buy_now_data', None)
        else:
            CartItem.query.filter_by(user_id=current_user.id).delete()
        
        # Clear pending order
        session.pop('pending_order', None)
        
        # Award loyalty points
        points = calculate_loyalty_points(pending_order['total_amount'])
        current_user.loyalty_points += points
        
        db.session.commit()
        
        flash('Payment successful! Order confirmed.', 'success')
        return redirect(url_for('order_confirmation', order_id=order.id))
        
    except Exception as e:
        db.session.rollback()
        flash('Payment processing failed. Please contact support.', 'danger')
        return redirect(url_for('checkout'))

@app.route('/order_confirmation/<int:order_id>')
@login_required
def order_confirmation(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    return render_template('order_confirmation.html', order=order)

@app.route('/request_return/<int:order_id>/<int:product_id>', methods=['POST'])
@login_required
def request_return(order_id, product_id):
    """Request a return for a product"""
    order = Order.query.get_or_404(order_id)
    
    if order.user_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('profile'))
    
    if not can_return_order(order):
        flash('Return period has expired. Returns are only allowed within 2 days of delivery.', 'danger')
        return redirect(url_for('profile'))
    
    # Check if return already requested
    existing_return = Return.query.filter_by(
        order_id=order_id, 
        product_id=product_id,
        user_id=current_user.id
    ).first()
    
    if existing_return:
        flash('Return already requested for this product.', 'info')
        return redirect(url_for('profile'))
    
    # Get order item details
    order_item = OrderItem.query.filter_by(order_id=order_id, product_id=product_id).first()
    if not order_item:
        flash('Product not found in this order.', 'danger')
        return redirect(url_for('profile'))
    
    # Create return request
    return_request = Return()
    return_request.order_id = order_id
    return_request.user_id = current_user.id
    return_request.product_id = product_id
    return_request.quantity = order_item.quantity
    return_request.size = order_item.size
    return_request.reason = request.form.get('reason', 'No reason provided')
    return_request.return_amount = order_item.price * order_item.quantity
    return_request.status = 'requested'
    
    db.session.add(return_request)
    db.session.commit()
    
    flash('Return request submitted successfully. We will review and respond within 24 hours.', 'success')
    return redirect(url_for('profile'))

@app.route('/request_exchange/<int:order_id>/<int:product_id>', methods=['POST'])
@login_required
def request_exchange(order_id, product_id):
    """Request an exchange for a product"""
    order = Order.query.get_or_404(order_id)
    
    if order.user_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('profile'))
    
    if not can_return_order(order):
        flash('Exchange period has expired. Exchanges are only allowed within 2 days of delivery.', 'danger')
        return redirect(url_for('profile'))
    
    # Check if exchange already requested
    existing_exchange = Exchange.query.filter_by(
        order_id=order_id, 
        original_product_id=product_id,
        user_id=current_user.id
    ).first()
    
    if existing_exchange:
        flash('Exchange already requested for this product.', 'info')
        return redirect(url_for('profile'))
    
    # Get order item details
    order_item = OrderItem.query.filter_by(order_id=order_id, product_id=product_id).first()
    if not order_item:
        flash('Product not found in this order.', 'danger')
        return redirect(url_for('profile'))
    
    # Create exchange request
    exchange_request = Exchange()
    exchange_request.order_id = order_id
    exchange_request.user_id = current_user.id
    exchange_request.original_product_id = product_id
    exchange_request.original_size = order_item.size
    exchange_request.new_product_id = request.form.get('new_product_id', product_id, type=int)
    exchange_request.new_size = request.form.get('new_size', order_item.size)
    exchange_request.quantity = order_item.quantity
    exchange_request.reason = request.form.get('reason', 'No reason provided')
    exchange_request.exchange_charge = 99.0
    exchange_request.status = 'requested'
    
    db.session.add(exchange_request)
    db.session.commit()
    
    flash('Exchange request submitted successfully. Rs. 99 exchange charge will be applicable. We will review and respond within 24 hours.', 'success')
    return redirect(url_for('profile'))

# Admin routes
@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Dashboard statistics
    total_orders = Order.query.count()
    total_customers = User.query.filter_by(is_admin=False).count()
    total_products = Product.query.count()
    total_revenue = db.session.query(func.sum(Order.total_amount)).filter(
        Order.payment_status == 'completed'
    ).scalar() or 0
    
    # Recent orders
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    
    # Monthly revenue chart data
    monthly_revenue = db.session.query(
        extract('month', Order.created_at).label('month'),
        func.sum(Order.total_amount).label('revenue')
    ).filter(
        Order.payment_status == 'completed',
        extract('year', Order.created_at) == datetime.now().year
    ).group_by(extract('month', Order.created_at)).all()
    
    return render_template('admin/dashboard.html', 
                         total_orders=total_orders,
                         total_customers=total_customers,
                         total_products=total_products,
                         total_revenue=total_revenue,
                         recent_orders=recent_orders,
                         monthly_revenue=monthly_revenue)

@app.route('/admin/products')
@login_required
def admin_products():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    products = Product.query.all()
    categories = Category.query.all()
    return render_template('admin/products.html', products=products, categories=categories)

@app.route('/admin/inventory')
@login_required
def admin_inventory():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Get inventory data with product information
    inventory_data = db.session.query(
        Product.id,
        Product.name,
        Category.name.label('category_name'),
        Inventory.size,
        Inventory.quantity
    ).join(Category).join(Inventory).all()
    
    # Get low stock items (less than 10)
    low_stock = db.session.query(
        Product.name,
        Inventory.size,
        Inventory.quantity
    ).join(Inventory).filter(Inventory.quantity < 10).all()
    
    return render_template('admin/inventory.html', 
                         inventory_data=inventory_data,
                         low_stock=low_stock)

@app.route('/admin/discounts', methods=['GET', 'POST'])
@login_required
def admin_discounts():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        # Create new discount
        discount = Discount()
        discount.code = request.form['code'].upper()
        discount.description = request.form['description']
        discount.discount_type = request.form['discount_type']
        discount.discount_value = float(request.form['discount_value'])
        discount.min_order_amount = float(request.form.get('min_order_amount', 0))
        discount.max_discount = float(request.form['max_discount']) if request.form.get('max_discount') else None
        discount.usage_limit = int(request.form['usage_limit']) if request.form.get('usage_limit') else None
        discount.valid_until = datetime.strptime(request.form['valid_until'], '%Y-%m-%d') if request.form.get('valid_until') else None
        
        try:
            db.session.add(discount)
            db.session.commit()
            flash('Discount code created successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Error creating discount code. Code might already exist.', 'danger')
        
        return redirect(url_for('admin_discounts'))
    
    discounts = Discount.query.all()
    return render_template('admin/discounts.html', discounts=discounts)

@app.route('/admin/orders')
@login_required
def admin_orders():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders.html', orders=orders)

@app.route('/admin/customers')
@login_required
def admin_customers():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    customers = User.query.filter_by(is_admin=False).order_by(User.created_at.desc()).all()
    return render_template('admin/customers.html', customers=customers)

@app.route('/admin/returns')
@login_required
def admin_returns():
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    returns = Return.query.order_by(Return.created_at.desc()).all()
    exchanges = Exchange.query.order_by(Exchange.created_at.desc()).all()
    
    return render_template('admin/returns.html', returns=returns, exchanges=exchanges)

@app.route('/admin/update_order_status/<int:order_id>', methods=['POST'])
@login_required
def update_order_status(order_id):
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    order = Order.query.get_or_404(order_id)
    new_status = request.form['status']
    
    order.order_status = new_status
    order.updated_at = datetime.utcnow()
    
    db.session.commit()
    flash(f'Order #{order_id} status updated to {new_status}', 'success')
    
    return redirect(url_for('admin_orders'))

@app.route('/admin/process_return/<int:return_id>', methods=['POST'])
@login_required
def process_return(return_id):
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    return_request = Return.query.get_or_404(return_id)
    action = request.form['action']
    admin_notes = request.form.get('admin_notes', '')
    
    if action == 'approve':
        return_request.status = 'approved'
        return_request.approved_at = datetime.utcnow()
        flash(f'Return request #{return_id} approved', 'success')
    elif action == 'reject':
        return_request.status = 'rejected'
        flash(f'Return request #{return_id} rejected', 'info')
    elif action == 'complete':
        return_request.status = 'completed'
        return_request.completed_at = datetime.utcnow()
        
        # Restore inventory
        inventory = Inventory.query.filter_by(
            product_id=return_request.product_id,
            size=return_request.size
        ).first()
        if inventory:
            inventory.quantity += return_request.quantity
        
        flash(f'Return request #{return_id} completed', 'success')
    
    return_request.admin_notes = admin_notes
    db.session.commit()
    
    return redirect(url_for('admin_returns'))

@app.route('/admin/process_exchange/<int:exchange_id>', methods=['POST'])
@login_required
def process_exchange(exchange_id):
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    exchange_request = Exchange.query.get_or_404(exchange_id)
    action = request.form['action']
    admin_notes = request.form.get('admin_notes', '')
    
    if action == 'approve':
        exchange_request.status = 'approved'
        exchange_request.approved_at = datetime.utcnow()
        flash(f'Exchange request #{exchange_id} approved', 'success')
    elif action == 'reject':
        exchange_request.status = 'rejected'
        flash(f'Exchange request #{exchange_id} rejected', 'info')
    elif action == 'complete':
        exchange_request.status = 'completed'
        exchange_request.completed_at = datetime.utcnow()
        
        # Update inventory - restore original, reduce new
        original_inventory = Inventory.query.filter_by(
            product_id=exchange_request.original_product_id,
            size=exchange_request.original_size
        ).first()
        if original_inventory:
            original_inventory.quantity += exchange_request.quantity
            
        new_inventory = Inventory.query.filter_by(
            product_id=exchange_request.new_product_id,
            size=exchange_request.new_size
        ).first()
        if new_inventory:
            new_inventory.quantity -= exchange_request.quantity
        
        flash(f'Exchange request #{exchange_id} completed', 'success')
    
    exchange_request.admin_notes = admin_notes
    db.session.commit()
    
    return redirect(url_for('admin_returns'))

@app.route('/admin/export/<data_type>')
@login_required
def export_data(data_type):
    if not current_user.can_access_admin():
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    try:
        filename = export_data_to_excel(data_type)
        flash(f'Data exported successfully: {filename}', 'success')
    except Exception as e:
        flash(f'Export failed: {str(e)}', 'danger')
    
    return redirect(url_for('admin_dashboard'))
