from app import app, db
from models import User

with app.app_context():
    admin_user = User.query.filter_by(email='admin@anniejameszone.com').first()
    if admin_user:
        admin_user.set_password('Admin@123')
        db.session.commit()
        print("Admin password updated.")
    else:
        print("Admin user not found.")
