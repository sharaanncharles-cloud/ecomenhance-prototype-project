# Overview

Annie James Zone is a comprehensive e-commerce web application built with Flask that provides a complete online fashion shopping experience. The application features user authentication, product catalog management, shopping cart functionality, order processing, payment integration, and a comprehensive admin panel. It includes advanced features like loyalty programs, discount systems, returns/exchanges management, and detailed analytics.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Jinja2 templates with Bootstrap 5 for responsive, mobile-first design
- **Theme**: Dark mode implementation using Bootstrap's dark theme with custom CSS variables and gradients
- **JavaScript**: Vanilla JavaScript organized in modular functions for cart management, search, form validation, payment integration, and interactive features
- **CSS Framework**: Custom CSS built on Bootstrap with fashion-specific styling, animations, and card-based layouts
- **User Interface**: Modern card-based layouts with intuitive navigation, hover effects, and visual feedback

## Backend Architecture
- **Framework**: Flask web framework with modular route organization and application factory pattern
- **Database ORM**: SQLAlchemy with declarative base pattern for robust database operations and relationship management
- **Authentication**: Flask-Login for session management with multi-tier role-based access control (users, limited admins, super admins)
- **Security**: Werkzeug password hashing, session management, CSRF protection, and input validation
- **Application Structure**:
  - `app.py` - Application factory with configuration and extension initialization
  - `routes.py` - URL route handlers with business logic separation
  - `models.py` - Database models with relationships and business methods
  - `utils.py` - Utility functions for email, payments, calculations, and data export
  - `main.py` - Application entry point for deployment

## Database Schema Design
- **User Management**: Comprehensive user profiles with authentication, detailed address management, membership tiers (bronze, silver, gold, platinum), and loyalty points system
- **Product Catalog**: Products with categories, inventory tracking, pricing, discounts, image management, and size-based availability
- **E-commerce Features**: Shopping cart, wishlist, product interactions (likes, comments), and comprehensive inventory management
- **Order Management**: Complete order lifecycle with items, payment tracking, status management, fulfillment, returns, and exchanges
- **Admin System**: Multi-level admin access with different operational capabilities and analytics dashboard
- **Communication**: OTP verification system for secure registration and password reset operations

## Authentication & Authorization
- **Multi-tier Access Control**: Regular users, limited admins, and super admins with graduated permissions and role-based restrictions
- **OTP Verification**: Email-based OTP system for registration and password reset workflows with time-based expiration
- **Session Management**: Flask-Login handles user sessions, authentication state, login persistence, and logout functionality
- **Security Features**: Password strength validation, secure session secrets, form CSRF protection, and secure password storage

## Business Logic Features
- **Loyalty Program**: Points-based reward system with membership tier progression and tier-based benefits
- **Discount System**: Flexible discount codes supporting both percentage and fixed amount discounts with expiration dates and usage limits
- **Inventory Management**: Size-based stock tracking with low stock alerts, availability checks, and automatic inventory updates
- **Order Processing**: Complete order workflow with multiple payment method support including Razorpay integration and COD
- **Admin Analytics**: Comprehensive dashboard with revenue tracking, order analytics, customer insights, and data visualization
- **Data Export**: Excel export functionality for orders, customers, inventory, and sales reports for business intelligence

# External Dependencies

## Payment Integration
- **Razorpay**: Online payment gateway for secure card transactions, UPI payments, and payment verification
- **Cash on Delivery**: COD support with OTP verification and additional charges calculation

## Email Services
- **Brevo API**: Email service for OTP delivery, password reset notifications, and transactional emails with HTML template support

## Database
- **SQLite**: Default database for development with configurable PostgreSQL support for production via DATABASE_URL environment variable
- **SQLAlchemy**: ORM with connection pooling, pre-ping health checks, and connection recycling

## Frontend Libraries
- **Bootstrap 5**: CSS framework with dark theme support for responsive design
- **Font Awesome 6**: Icon library for comprehensive UI iconography
- **Chart.js**: JavaScript charting library for admin analytics and data visualization

## Development Tools
- **Pandas**: Data manipulation and Excel export functionality for admin reports
- **Werkzeug**: WSGI utilities including ProxyFix middleware for deployment behind reverse proxies
- **Flask Extensions**: Flask-SQLAlchemy for database integration and Flask-Login for session management