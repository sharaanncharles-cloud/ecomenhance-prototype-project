// Annie James Zone - Main JavaScript File

// Global application object
const AJZ = {
    init: function() {
        this.initializeComponents();
        this.setupEventListeners();
        this.loadUserPreferences();
    },

    // Initialize Bootstrap components
    initializeComponents: function() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Initialize popovers
        const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        popoverTriggerList.map(function (popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });

        // Initialize modals
        const modalList = [].slice.call(document.querySelectorAll('.modal'));
        modalList.map(function (modalEl) {
            return new bootstrap.Modal(modalEl);
        });

        // Initialize alerts with auto-dismiss
        this.initializeAlerts();
    },

    // Setup event listeners
    setupEventListeners: function() {
        // Search functionality
        this.setupSearch();
        
        // Cart functionality
        this.setupCart();
        
        // Product functionality
        this.setupProducts();
        
        // Form validation
        this.setupFormValidation();
        
        // Smooth scrolling
        this.setupSmoothScrolling();
        
        // Back to top button
        this.setupBackToTop();

        // Loading states
        this.setupLoadingStates();

        // Image lazy loading
        this.setupLazyLoading();
    },

    // Initialize auto-dismiss alerts
    initializeAlerts: function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            if (alert.classList.contains('alert-success') || alert.classList.contains('alert-info')) {
                setTimeout(() => {
                    const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
                    bsAlert.close();
                }, 5000);
            }
        });
    },

    // Setup search functionality
    setupSearch: function() {
        const searchInput = document.querySelector('.search-box');
        if (searchInput) {
            let searchTimeout;
            
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    // Implement search suggestions here
                    AJZ.handleSearchSuggestions(this.value);
                }, 300);
            });

            // Search form submission
            const searchForm = searchInput.closest('form');
            if (searchForm) {
                searchForm.addEventListener('submit', function(e) {
                    if (searchInput.value.trim() === '') {
                        e.preventDefault();
                        AJZ.showMessage('Please enter a search term', 'warning');
                    }
                });
            }
        }
    },

    // Handle search suggestions
    handleSearchSuggestions: function(query) {
        if (query.length < 2) return;
        
        // This would typically make an AJAX call to get suggestions
        console.log('Searching for:', query);
    },

    // Setup cart functionality
    setupCart: function() {
        // Add to cart buttons
        document.addEventListener('click', function(e) {
            if (e.target.matches('.add-to-cart-btn') || e.target.closest('.add-to-cart-btn')) {
                e.preventDefault();
                const form = e.target.closest('form');
                if (form) {
                    AJZ.addToCart(form);
                }
            }
        });

        // Update cart quantity
        document.addEventListener('change', function(e) {
            if (e.target.matches('input[name^="quantity_"]')) {
                AJZ.updateCartItem(e.target);
            }
        });

        // Remove from cart
        document.addEventListener('click', function(e) {
            if (e.target.matches('.remove-from-cart') || e.target.closest('.remove-from-cart')) {
                e.preventDefault();
                if (confirm('Are you sure you want to remove this item from your cart?')) {
                    window.location.href = e.target.href || e.target.closest('a').href;
                }
            }
        });
    },

    // Add item to cart with animation
    addToCart: function(form) {
        const button = form.querySelector('.add-to-cart-btn');
        const originalText = button.innerHTML;
        
        // Show loading state
        button.disabled = true;
        button.innerHTML = '<span class="loading-spinner me-2"></span>Adding...';
        
        // Simulate form submission (in real app, this would be AJAX)
        setTimeout(() => {
            form.submit();
        }, 1000);
    },

    // Update cart item quantity
    updateCartItem: function(input) {
        const itemId = input.name.replace('quantity_', '');
        const quantity = parseInt(input.value) || 0;
        
        if (quantity === 0) {
            if (confirm('Remove this item from cart?')) {
                // Remove item
                input.closest('tr').classList.add('fade-out');
                setTimeout(() => {
                    input.closest('form').submit();
                }, 300);
            } else {
                input.value = 1;
            }
        }
        
        // Update item total (if price data is available)
        this.updateItemTotal(itemId, quantity);
    },

    // Update individual item total
    updateItemTotal: function(itemId, quantity) {
        const priceElement = document.querySelector(`[data-price-for="${itemId}"]`);
        const totalElement = document.querySelector(`[data-total-for="${itemId}"]`);
        
        if (priceElement && totalElement) {
            const price = parseFloat(priceElement.dataset.price) || 0;
            const total = price * quantity;
            totalElement.textContent = `₹${total.toFixed(2)}`;
            
            // Update cart total
            this.updateCartTotal();
        }
    },

    // Update cart total
    updateCartTotal: function() {
        let total = 0;
        document.querySelectorAll('[data-total-for]').forEach(element => {
            const amount = parseFloat(element.textContent.replace('₹', '')) || 0;
            total += amount;
        });
        
        const cartTotalElements = document.querySelectorAll('.cart-total');
        cartTotalElements.forEach(element => {
            element.textContent = `₹${total.toFixed(2)}`;
        });
    },

    // Setup product functionality
    setupProducts: function() {
        // Product image gallery
        document.addEventListener('click', function(e) {
            if (e.target.matches('.product-thumbnail')) {
                const mainImage = document.querySelector('.main-product-image');
                if (mainImage) {
                    mainImage.src = e.target.src;
                }
            }
        });

        // Size selection
        document.addEventListener('change', function(e) {
            if (e.target.matches('input[name="size"]')) {
                AJZ.updateSizeSelection(e.target);
            }
        });

        // Quantity controls
        document.addEventListener('click', function(e) {
            if (e.target.matches('.quantity-btn')) {
                e.preventDefault();
                const input = e.target.parentElement.querySelector('input[type="number"]');
                const action = e.target.dataset.action;
                
                if (action === 'increase') {
                    input.value = Math.min(parseInt(input.value) + 1, parseInt(input.max) || 99);
                } else if (action === 'decrease') {
                    input.value = Math.max(parseInt(input.value) - 1, parseInt(input.min) || 1);
                }
                
                input.dispatchEvent(new Event('change'));
            }
        });

        // Product reviews
        this.setupProductReviews();
    },

    // Update size selection
    updateSizeSelection: function(sizeInput) {
        const productForm = sizeInput.closest('form');
        const addToCartBtn = productForm.querySelector('.add-to-cart-btn');
        
        // Check stock for selected size
        const stock = parseInt(sizeInput.dataset.stock) || 0;
        
        if (stock === 0) {
            addToCartBtn.disabled = true;
            addToCartBtn.textContent = 'Out of Stock';
        } else {
            addToCartBtn.disabled = false;
            addToCartBtn.innerHTML = '<i class="fas fa-shopping-cart me-2"></i>Add to Cart';
        }
    },

    // Setup product reviews
    setupProductReviews: function() {
        // Star rating interaction
        document.addEventListener('click', function(e) {
            if (e.target.matches('.rating-input .star-label') || e.target.closest('.rating-input .star-label')) {
                const stars = e.target.closest('.rating-input').querySelectorAll('.star-label');
                const clickedIndex = Array.from(stars).indexOf(e.target.closest('.star-label'));
                
                stars.forEach((star, index) => {
                    const icon = star.querySelector('i');
                    if (index <= clickedIndex) {
                        icon.classList.remove('text-muted');
                        icon.classList.add('text-warning');
                    } else {
                        icon.classList.remove('text-warning');
                        icon.classList.add('text-muted');
                    }
                });
            }
        });
    },

    // Setup form validation
    setupFormValidation: function() {
        // Bootstrap form validation
        const forms = document.querySelectorAll('.needs-validation');
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                    
                    // Focus on first invalid field
                    const firstInvalid = form.querySelector(':invalid');
                    if (firstInvalid) {
                        firstInvalid.focus();
                    }
                }
                form.classList.add('was-validated');
            });
        });

        // Custom password validation
        const passwordInputs = document.querySelectorAll('input[type="password"]');
        passwordInputs.forEach(input => {
            if (input.name === 'password' && !input.id.includes('confirm')) {
                input.addEventListener('input', () => {
                    this.validatePassword(input);
                });
            }
        });

        // Confirm password validation
        const confirmPasswordInputs = document.querySelectorAll('input[name="confirm_password"]');
        confirmPasswordInputs.forEach(input => {
            input.addEventListener('input', () => {
                this.validateConfirmPassword(input);
            });
        });

        // Email validation
        const emailInputs = document.querySelectorAll('input[type="email"]');
        emailInputs.forEach(input => {
            input.addEventListener('blur', () => {
                this.validateEmail(input);
            });
        });

        // Phone number validation
        const phoneInputs = document.querySelectorAll('input[type="tel"]');
        phoneInputs.forEach(input => {
            input.addEventListener('input', () => {
                this.validatePhone(input);
            });
        });
    },

    // Validate password strength
    validatePassword: function(input) {
        const password = input.value;
        const feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        
        // Remove existing feedback
        const existingFeedback = input.parentElement.querySelector('.invalid-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }

        const requirements = {
            length: password.length >= 8 && password.length <= 20,
            lowercase: /[a-z]/.test(password),
            uppercase: /[A-Z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        const failedRequirements = [];
        if (!requirements.length) failedRequirements.push('8-20 characters');
        if (!requirements.lowercase) failedRequirements.push('lowercase letter');
        if (!requirements.uppercase) failedRequirements.push('uppercase letter');
        if (!requirements.number) failedRequirements.push('number');
        if (!requirements.special) failedRequirements.push('special character');

        if (failedRequirements.length > 0) {
            input.setCustomValidity('Invalid password');
            feedback.textContent = `Password must contain: ${failedRequirements.join(', ')}`;
            input.parentElement.appendChild(feedback);
            input.classList.add('is-invalid');
        } else {
            input.setCustomValidity('');
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
        }
    },

    // Validate confirm password
    validateConfirmPassword: function(input) {
        const password = document.querySelector('input[name="password"]').value;
        const confirmPassword = input.value;

        if (password !== confirmPassword) {
            input.setCustomValidity('Passwords do not match');
            input.classList.add('is-invalid');
        } else {
            input.setCustomValidity('');
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
        }
    },

    // Validate email format
    validateEmail: function(input) {
        const email = input.value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (email && !emailRegex.test(email)) {
            input.setCustomValidity('Please enter a valid email address');
            input.classList.add('is-invalid');
        } else {
            input.setCustomValidity('');
            input.classList.remove('is-invalid');
            if (email) input.classList.add('is-valid');
        }
    },

    // Validate phone number
    validatePhone: function(input) {
        const phone = input.value.replace(/\D/g, '');
        
        // Format phone number as user types
        if (phone.length === 10) {
            input.value = phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
            input.setCustomValidity('');
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
        } else if (phone.length > 0) {
            input.setCustomValidity('Please enter a valid 10-digit phone number');
            input.classList.add('is-invalid');
        } else {
            input.setCustomValidity('');
            input.classList.remove('is-invalid', 'is-valid');
        }
    },

    // Setup smooth scrolling
    setupSmoothScrolling: function() {
        document.addEventListener('click', function(e) {
            if (e.target.matches('a[href^="#"]') && e.target.getAttribute('href') !== '#') {
                e.preventDefault();
                const target = document.querySelector(e.target.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    },

    // Setup back to top button
    setupBackToTop: function() {
        const backToTopBtn = document.createElement('button');
        backToTopBtn.innerHTML = '<i class="fas fa-chevron-up"></i>';
        backToTopBtn.className = 'btn btn-primary position-fixed bottom-0 end-0 m-3 rounded-circle back-to-top';
        backToTopBtn.style.display = 'none';
        backToTopBtn.style.zIndex = '1050';
        document.body.appendChild(backToTopBtn);

        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.style.display = 'block';
            } else {
                backToTopBtn.style.display = 'none';
            }
        });

        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    },

    // Setup loading states for buttons and forms
    setupLoadingStates: function() {
        document.addEventListener('submit', function(e) {
            const form = e.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            
            if (submitBtn && !submitBtn.disabled) {
                const originalText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="loading-spinner me-2"></span>Processing...';
                
                // Re-enable after 30 seconds to prevent permanent disable
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }, 30000);
            }
        });
    },

    // Setup lazy loading for images
    setupLazyLoading: function() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    },

    // Load user preferences from localStorage
    loadUserPreferences: function() {
        const preferences = JSON.parse(localStorage.getItem('ajz_preferences') || '{}');
        
        // Apply theme preference
        if (preferences.theme) {
            document.documentElement.setAttribute('data-bs-theme', preferences.theme);
        }

        // Apply other preferences
        if (preferences.fontSize) {
            document.documentElement.style.fontSize = preferences.fontSize;
        }
    },

    // Save user preferences
    savePreferences: function(key, value) {
        const preferences = JSON.parse(localStorage.getItem('ajz_preferences') || '{}');
        preferences[key] = value;
        localStorage.setItem('ajz_preferences', JSON.stringify(preferences));
    },

    // Show message to user
    showMessage: function(message, type = 'info', duration = 5000) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x`;
        alertDiv.style.zIndex = '9999';
        alertDiv.style.marginTop = '20px';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto dismiss
        setTimeout(() => {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alertDiv);
            bsAlert.close();
        }, duration);
    },

    // Utility function to format currency
    formatCurrency: function(amount) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        }).format(amount);
    },

    // Utility function to format date
    formatDate: function(date, options = {}) {
        const defaultOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        };
        return new Date(date).toLocaleDateString('en-IN', { ...defaultOptions, ...options });
    },

    // Utility function to debounce function calls
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Utility function to throttle function calls
    throttle: function(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    },

    // Admin panel specific functions
    admin: {
        // Refresh dashboard data
        refreshDashboard: function() {
            // This would make AJAX calls to refresh dashboard data
            console.log('Refreshing dashboard data...');
            AJZ.showMessage('Dashboard data refreshed', 'success');
        },

        // Export data
        exportData: function(type) {
            const btn = event.target;
            const originalText = btn.innerHTML;
            
            btn.disabled = true;
            btn.innerHTML = '<span class="loading-spinner me-2"></span>Exporting...';
            
            // Simulate export process
            setTimeout(() => {
                btn.disabled = false;
                btn.innerHTML = originalText;
                AJZ.showMessage(`${type} data exported successfully`, 'success');
            }, 2000);
        },

        // Bulk actions
        setupBulkActions: function() {
            const selectAllCheckbox = document.getElementById('selectAll');
            const itemCheckboxes = document.querySelectorAll('.item-checkbox');
            const bulkActionBtn = document.getElementById('bulkAction');
            
            if (selectAllCheckbox) {
                selectAllCheckbox.addEventListener('change', function() {
                    itemCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                    AJZ.admin.updateBulkActionButton();
                });
            }
            
            itemCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    AJZ.admin.updateBulkActionButton();
                });
            });
        },

        // Update bulk action button state
        updateBulkActionButton: function() {
            const selectedItems = document.querySelectorAll('.item-checkbox:checked');
            const bulkActionBtn = document.getElementById('bulkAction');
            
            if (bulkActionBtn) {
                if (selectedItems.length > 0) {
                    bulkActionBtn.disabled = false;
                    bulkActionBtn.textContent = `Action (${selectedItems.length} selected)`;
                } else {
                    bulkActionBtn.disabled = true;
                    bulkActionBtn.textContent = 'Select items';
                }
            }
        }
    }
};

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    AJZ.init();
    
    // Initialize admin functions if on admin page
    if (document.querySelector('.admin-content') || window.location.pathname.includes('/admin')) {
        AJZ.admin.setupBulkActions();
    }
});

// Export for use in other scripts
window.AJZ = AJZ;

// Service Worker registration for PWA functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('SW registered: ', registration);
            })
            .catch(function(registrationError) {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// Global error handler
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
    
    // Don't show error messages in production
    if (window.location.hostname !== 'localhost') {
        return;
    }
    
    AJZ.showMessage('An unexpected error occurred. Please try again.', 'danger');
});

// Handle offline/online status
window.addEventListener('online', function() {
    AJZ.showMessage('Connection restored', 'success');
});

window.addEventListener('offline', function() {
    AJZ.showMessage('You are currently offline', 'warning');
});
