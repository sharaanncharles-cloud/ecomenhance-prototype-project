import os
import random
import string
from datetime import datetime, timedelta
from flask import render_template, request, redirect, url_for, flash, jsonify, session, make_response
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from datetime import datetime
from models import (User, Product, Category, Inventory, Order, OrderItem, 
                   CartItem, WishlistItem, Comment, Like, Discount, OTPVerification,
                   Return, Exchange, Feedback)
from utils import (send_otp_email, calculate_loyalty_points, calculate_discount, 
                  validate_password, create_razorpay_order, verify_razorpay_payment, 
                  export_data_to_excel, can_return_order, calculate_cod_charge, 
                  apply_discount_code, generate_cod_otp, send_cod_otp_sms, generate_tracking_number)
from sqlalchemy import func, extract
from utils import send_custom_email

import json

@app.route('/')
def index():
    featured_products = Product.query.filter_by(is_active=True).limit(8).all()
    categories = Category.query.all()
    return render_template('index.html', products=featured_products, categories=categories, datetime=datetime)

@app.context_processor
def inject_now():
    return {'datetime': datetime}

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.form
        
        # Validate password
        is_valid, message = validate_password(data['password'])
        if not is_valid:
            flash(message, 'danger')
            return redirect(url_for('register'))
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
        
        # Create user directly without OTP verification
        user = User()
        user.username = data['email']  # Use email as username
        user.email = data['email']
        user.full_name = data['full_name']
        user.phone = data['phone']
        user.is_verified = True  # Skip OTP verification
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/verify_otp/<purpose>', methods=['GET', 'POST'])
def verify_otp(purpose):
    if request.method == 'POST':
        otp = request.form['otp']
        
        if purpose == 'password_reset':
            email = session.get('reset_email')
            if not email:
                flash('Session expired. Please try again.', 'danger')
                return redirect(url_for('forgot_password'))
            
            # Check OTP and expiration (10 minutes)
            otp_record = OTPVerification.query.filter_by(
                email=email, otp=otp, purpose='password_reset', is_used=False
            ).first()
            
            if otp_record and otp_record.created_at > datetime.utcnow() - timedelta(minutes=10):
                otp_record.is_used = True
                db.session.commit()
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid or expired OTP. OTP expires after 10 minutes.', 'danger')
    
    return render_template('verify_otp.html', purpose=purpose)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check both email and username for login compatibility
        user = User.query.filter((User.email == username) | (User.username == username)).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Generate and send OTP
            otp = ''.join(random.choices(string.digits, k=6))
            
            otp_record = OTPVerification()
            otp_record.email = email
            otp_record.otp = otp
            otp_record.purpose = 'password_reset'
            db.session.add(otp_record)
            db.session.commit()
            
            session['reset_email'] = email
            
            if send_otp_email(email, otp):
                flash('OTP sent to your email. Please verify within 10 minutes.', 'info')
                return redirect(url_for('verify_otp', purpose='password_reset'))
            else:
                flash('Failed to send OTP. Please try again.', 'danger')
        else:
            flash('Email not found', 'danger')
    
    return render_template('forgot_password.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    email = session.get('reset_email')
    if not email:
        flash('Session expired. Please try again.', 'danger')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('reset_password.html')
        
        # Validate password
        is_valid, message = validate_password(password)
        if not is_valid:
            flash(message, 'danger')
            return render_template('reset_password.html')
        
        user = User.query.filter_by(email=email).first()
        if user:
            user.set_password(password)
            db.session.commit()
            session.pop('reset_email', None)
            flash('Password reset successful! Please login.', 'success')
            return redirect(url_for('login'))
    
    return render_template('reset_password.html')

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        # Update profile information
        current_user.full_name = request.form.get('full_name', current_user.full_name)
        current_user.phone = request.form.get('phone', current_user.phone)
        current_user.house_number = request.form.get('house_number', current_user.house_number)
        current_user.locality = request.form.get('locality', current_user.locality)
        current_user.apartment_name = request.form.get('apartment_name', current_user.apartment_name)
        current_user.landmark = request.form.get('landmark', current_user.landmark)
        current_user.street_name = request.form.get('street_name', current_user.street_name)
        current_user.city = request.form.get('city', current_user.city)
        current_user.state = request.form.get('state', current_user.state)
        current_user.pincode = request.form.get('pincode', current_user.pincode)
        
        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))
    
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('profile.html', orders=orders)

@app.route('/products')
def products():
    category_id = request.args.get('category', type=int)
    search = request.args.get('search', '')
    
    query = Product.query.filter_by(is_active=True)
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if search:
        query = query.filter(Product.name.ilike(f'%{search}%'))
    
    products = query.all()
    categories = Category.query.all()
    
    return render_template('products.html', products=products, categories=categories, 
                         selected_category=category_id, search=search)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    comments = Comment.query.filter_by(product_id=product_id).order_by(Comment.created_at.desc()).all()
    feedback_items = Feedback.query.filter_by(product_id=product_id, is_approved=True).order_by(Feedback.created_at.desc()).all()
    sizes = [inv.size for inv in product.inventory if inv.quantity > 0]
    
    # Check if user has liked this product
    user_liked = False
    if current_user.is_authenticated:
        user_liked = Like.query.filter_by(user_id=current_user.id, product_id=product_id).first() is not None
    
    return render_template('product_detail.html', product=product, comments=comments, 
                         feedback_items=feedback_items, sizes=sizes, user_liked=user_liked)

@app.route('/buy_now', methods=['POST'])
@login_required
def buy_now():
    """Direct buy now functionality - bypass cart"""
    product_id = request.form.get('product_id', type=int)
    size = request.form.get('size')
    quantity = request.form.get('quantity', 1, type=int)
    
    product = Product.query.get_or_404(product_id)
    
    # Check stock availability
    inventory = Inventory.query.filter_by(product_id=product_id, size=size).first()
    if not inventory or inventory.quantity < quantity:
        flash('Insufficient stock for the selected size', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))
    
    # Store buy now data in session
    session['buy_now_data'] = {
        'product_id': product_id,
        'size': size,
        'quantity': quantity,
        'price': product.get_price()
    }
    
    return redirect(url_for('checkout'))

@app.route('/add_to_cart', methods=['POST'])
@login_required
def add_to_cart():
    product_id = request.form.get('product_id', type=int)
    size = request.form.get('size')
    quantity = request.form.get('quantity', 1, type=int)
    
    # Check if item already in cart
    existing_item = CartItem.query.filter_by(
        user_id=current_user.id, product_id=product_id, size=size
    ).first()
    
    if existing_item:
        existing_item.quantity += quantity
    else:
        cart_item = CartItem()
        cart_item.user_id = current_user.id
        cart_item.product_id = product_id
        cart_item.size = size
        cart_item.quantity = quantity
        db.session.add(cart_item)
    
    db.session.commit()
    flash('Item added to cart', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/get_stock/<int:product_id>/<size>')
def get_stock(product_id, size):
    from models import Inventory
    inventory_item = Inventory.query.filter_by(product_id=product_id, size=size).first()
    stock_count = inventory_item.quantity if inventory_item else 0
    return jsonify({'stock': stock_count})

@app.route('/cart')
@login_required
def cart():
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    total = sum(item.product.get_price() * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@app.route('/remove_from_cart/<int:item_id>')
@login_required
def remove_from_cart(item_id):
    item = CartItem.query.get_or_404(item_id)
    if item.user_id == current_user.id:
        db.session.delete(item)
        db.session.commit()
        flash('Item removed from cart', 'info')
    return redirect(url_for('cart'))

@app.route('/update_cart', methods=['POST'])
@login_required
def update_cart():
    for key, value in request.form.items():
        if key.startswith('quantity_'):
            item_id = int(key.replace('quantity_', ''))
            quantity = int(value) if value else 0
            
            item = CartItem.query.get(item_id)
            if item and item.user_id == current_user.id:
                if quantity > 0:
                    item.quantity = quantity
                else:
                    db.session.delete(item)
    
    db.session.commit()
    flash('Cart updated', 'success')
    return redirect(url_for('cart'))

@app.route('/wishlist')
@login_required
def wishlist():
    wishlist_items = WishlistItem.query.filter_by(user_id=current_user.id).all()
    return render_template('wishlist.html', wishlist_items=wishlist_items)

@app.route('/add_to_wishlist/<int:product_id>')
@login_required
def add_to_wishlist(product_id):
    existing_item = WishlistItem.query.filter_by(
        user_id=current_user.id, product_id=product_id
    ).first()
    
    if not existing_item:
        wishlist_item = WishlistItem()
        wishlist_item.user_id = current_user.id
        wishlist_item.product_id = product_id
        db.session.add(wishlist_item)
        db.session.commit()
        flash('Item added to wishlist', 'success')
    else:
        flash('Item already in wishlist', 'info')
    
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/remove_from_wishlist/<int:item_id>')
@login_required
def remove_from_wishlist(item_id):
    item = WishlistItem.query.get_or_404(item_id)
    if item.user_id == current_user.id:
        db.session.delete(item)
        db.session.commit()
        flash('Item removed from wishlist', 'info')
    return redirect(url_for('wishlist'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    # Check if it's buy now or cart checkout
    buy_now_data = session.get('buy_now_data')
    cart_items = []
    total = 0
    
    if buy_now_data:
        # Buy now checkout
        product = Product.query.get(buy_now_data['product_id'])
        total = buy_now_data['price'] * buy_now_data['quantity']
        cart_items = [{
            'product': product,
            'size': buy_now_data['size'],
            'quantity': buy_now_data['quantity'],
            'price': buy_now_data['price']
        }]
    else:
        # Cart checkout
        db_cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
        if not db_cart_items:
            flash('Your cart is empty', 'warning')
            return redirect(url_for('cart'))
        
        for item in db_cart_items:
            cart_items.append({
                'product': item.product,
                'size': item.size,
                'quantity': item.quantity,
                'price': item.product.get_price()
            })
            total += item.product.get_price() * item.quantity
    
    if request.method == 'POST':
        # Process checkout
        payment_method = request.form.get('payment_method')
        discount_code = request.form.get('discount_code', '')
        
        # Apply discount if any
        discount_amount = 0
        if discount_code:
            discount_amount = calculate_discount(discount_code, total)
        
        # Calculate charges
        cod_charge = calculate_cod_charge(payment_method)
        shipping_charge = 100 if total < 1000 else 0  # Free shipping above ₹1000
        
        final_total = total - discount_amount + cod_charge + shipping_charge
        
        # Create order
        order = Order()
        order.user_id = current_user.id
        order.order_number = f'AJZ{datetime.now().strftime("%Y%m%d%H%M%S")}{random.randint(100, 999)}'
        order.total_amount = final_total
        order.discount_amount = discount_amount
        order.shipping_charge = shipping_charge
        order.cod_charge = cod_charge
        order.payment_method = payment_method
        
        # Build address string
        address_parts = []
        for field in ['house_number', 'locality', 'apartment_name', 'landmark', 'street_name', 'city', 'state', 'pincode']:
            value = getattr(current_user, field)
            if value:
                address_parts.append(str(value))
        order.shipping_address = ', '.join(address_parts)
        order.billing_address = order.shipping_address
        
        if payment_method == 'cod':
            order.payment_status = 'pending'
            order.cod_otp = generate_cod_otp()
            # Send COD OTP
            if current_user.phone:
                send_cod_otp_sms(current_user.phone, order.cod_otp)
        elif payment_method == 'razorpay':
            # Create Razorpay order
            success, razorpay_order = create_razorpay_order(final_total)
            if success:
                order.razorpay_order_id = razorpay_order['id']
                order.payment_status = 'pending'
            else:
                flash('Payment processing failed. Please try again.', 'danger')
                return render_template('checkout.html', cart_items=cart_items, total=total)
        # Auto-generate tracking number at order creation
        if not getattr(order, 'tracking_number', None):
            order.tracking_number = generate_tracking_number()

        db.session.add(order)
        db.session.flush()  # Get order ID
       
        
        # Add order items
        for item in cart_items:
            order_item = OrderItem()
            order_item.order_id = order.id
            order_item.product_id = item['product'].id
            order_item.size = item['size']
            order_item.quantity = item['quantity']
            order_item.price = item['price']
            db.session.add(order_item)
            
            # Update inventory
            inventory = Inventory.query.filter_by(
                product_id=item['product'].id, size=item['size']
            ).first()
            if inventory:
                inventory.quantity -= item['quantity']
        
        # Apply discount if used
        if discount_code and discount_amount > 0:
            apply_discount_code(discount_code, total)
        
        # Calculate and add loyalty points
        loyalty_points = calculate_loyalty_points(final_total)
        current_user.loyalty_points += loyalty_points
        
        db.session.commit()
        
        # Clear cart or buy now session
        if buy_now_data:
            session.pop('buy_now_data', None)
        else:
            CartItem.query.filter_by(user_id=current_user.id).delete()
            db.session.commit()
        
        if payment_method == 'cod':
            flash(f'Order placed successfully! COD OTP sent to your phone. Order number: {order.order_number}', 'success')
            return redirect(url_for('order_success', order_id=order.id))
        elif payment_method == 'razorpay':
            return render_template('razorpay_payment.html', 
                                 order=order, 
                                 razorpay_key_id=os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_dfgPVH8ltRmvRT'))
    
    return render_template('checkout.html', cart_items=cart_items, total=total)

@app.route('/payment_success', methods=['POST'])
@login_required
def payment_success():
    """Handle Razorpay payment success callback"""
    payment_id = request.form.get('razorpay_payment_id')
    order_id = request.form.get('razorpay_order_id')
    signature = request.form.get('razorpay_signature')
    
    # Verify payment
    if verify_razorpay_payment(payment_id, order_id, signature):
        # Find and update order
        order = Order.query.filter_by(razorpay_order_id=order_id).first()
        if order:
            order.payment_status = 'completed'
            order.razorpay_payment_id = payment_id
            order.order_status = 'confirmed'
            db.session.commit()
            # Ensure tracking number exists on successful payment
            if not order.tracking_number:
                order.tracking_number = generate_tracking_number()
            db.session.commit()
            
            flash('Payment successful! Your order has been confirmed.', 'success')
            return redirect(url_for('order_success', order_id=order.id))
    
    flash('Payment verification failed. Please contact support.', 'danger')
    return redirect(url_for('index'))

@app.route('/order_success/<int:order_id>')
@login_required
def order_success(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('index'))
    
    return render_template('order_success.html', order=order)

@app.route('/verify_cod_otp/<int:order_id>', methods=['POST'])
@login_required
def verify_cod_otp(order_id):
    """Verify COD OTP for delivery confirmation"""
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('index'))
    
    otp = request.form.get('otp')
    if otp == order.cod_otp:
        order.cod_verified = True
        order.payment_status = 'completed'
        order.order_status = 'delivered'
        db.session.commit()
        # Ensure tracking number exists when COD is verified
        if not order.tracking_number:
            order.tracking_number = generate_tracking_number()
        db.session.commit()
        flash('COD verified successfully! Order delivered.', 'success')
    else:
        flash('Invalid OTP. Please try again.', 'danger')
    
    return redirect(url_for('profile'))

@app.route('/admin/order_status')
@login_required
def admin_order_status():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))

    delivered_orders = Order.query.filter_by(order_status='delivered').all()
    undelivered_orders = Order.query.filter(Order.order_status != 'delivered').all()
    returned_orders = Return.query.order_by(Return.created_at.desc()).all()
    exchanged_orders = Exchange.query.order_by(Exchange.created_at.desc()).all()

    return render_template(
        'admin/order_status.html',
        delivered_orders=delivered_orders,
        undelivered_orders=undelivered_orders,
        returned_orders=returned_orders,
        exchanged_orders=exchanged_orders
    )


# Feedback routes
@app.route('/feedback', methods=['GET', 'POST'])
@login_required
def feedback():
    if request.method == 'POST':
        product_id = request.form.get('product_id', type=int)
        order_id = request.form.get('order_id', type=int)
        rating = request.form.get('rating', type=int)
        title = request.form.get('title')
        content = request.form.get('content')
        
        # Check if user has purchased this product (if product_id provided)
        is_verified_purchase = False
        if product_id and order_id:
            order_item = OrderItem.query.join(Order).filter(
                Order.user_id == current_user.id,
                Order.id == order_id,
                OrderItem.product_id == product_id
            ).first()
            is_verified_purchase = bool(order_item)
        
        feedback_item = Feedback()
        feedback_item.user_id = current_user.id
        feedback_item.product_id = product_id
        feedback_item.order_id = order_id
        feedback_item.rating = rating
        feedback_item.title = title
        feedback_item.content = content
        feedback_item.is_verified_purchase = is_verified_purchase
        
        db.session.add(feedback_item)
        db.session.commit()
        
        flash('Thank you for your feedback!', 'success')
        return redirect(url_for('feedback'))
    
    # Get user's orders for feedback form
    orders = Order.query.filter_by(user_id=current_user.id, payment_status='completed').all()
    user_feedback = Feedback.query.filter_by(user_id=current_user.id).order_by(Feedback.created_at.desc()).all()
    
    return render_template('feedback.html', orders=orders, user_feedback=user_feedback)

# Admin routes
@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Dashboard statistics
    stats = {
        'total_orders': Order.query.count(),
        'total_customers': User.query.filter_by(is_admin=False).count(),
        'total_revenue': db.session.query(func.sum(Order.total_amount)).filter(
            Order.payment_status == 'completed'
        ).scalar() or 0,
        'pending_orders': Order.query.filter_by(order_status='placed').count(),
    }
    
    # Recent orders
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(10).all()
    
    return render_template('admin/dashboard.html', stats=stats, recent_orders=recent_orders)

@app.route('/admin/customers')
@login_required
def admin_customers():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))

    search = request.args.get('search', '').strip()
    tier = request.args.get('tier', '')
    status = request.args.get('status', '')
    sort = request.args.get('sort', 'newest')

    query = User.query.filter_by(is_admin=False)

    if search:
        query = query.filter(
            (User.full_name.ilike(f"%{search}%")) |
            (User.username.ilike(f"%{search}%")) |
            (User.email.ilike(f"%{search}%"))
        )
    if tier:
        query = query.filter_by(membership_tier=tier)
    if status == 'verified':
        query = query.filter_by(is_verified=True)
    elif status == 'unverified':
        query = query.filter_by(is_verified=False)

    if sort == 'oldest':
        query = query.order_by(User.created_at.asc())
    elif sort == 'name':
        query = query.order_by(User.full_name.asc())
    elif sort == 'points':
        query = query.order_by(User.loyalty_points.desc())
    else:
        query = query.order_by(User.created_at.desc())

    customers = query.all()
    return render_template('admin/customers.html', customers=customers)

@app.route('/admin/customers/email', methods=['POST'])
@login_required
def admin_customers_email():
    if not current_user.is_admin:
        return jsonify({'status': 'error', 'message': 'Access denied'}), 403

    customer_ids = request.form.getlist('customer_ids[]')
    subject = request.form.get('subject')
    body = request.form.get('body')

    if not customer_ids or not subject or not body:
        return jsonify({'status': 'error', 'message': 'Missing fields'}), 400

    customers = User.query.filter(User.id.in_(customer_ids)).all()
    sent_count = 0
    for customer in customers:
        if send_custom_email(customer.email, subject, body):
            sent_count += 1

    return jsonify({'status': 'success', 'sent': sent_count})


@app.route('/admin/orders')
@login_required
def admin_orders():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    status_filter = request.args.get('status', '')
    
    query = Order.query
    if status_filter:
        query = query.filter_by(order_status=status_filter)
    
    orders = query.order_by(Order.created_at.desc()).all()
    
    return render_template('admin/orders.html', orders=orders, status_filter=status_filter)

@app.route('/admin/orders/<int:order_id>/update', methods=['POST'])
@login_required
def admin_update_order(order_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    order = Order.query.get_or_404(order_id)
    
    # Update order details
    order.order_status = request.form.get('order_status', order.order_status)
    order.tracking_number = request.form.get('tracking_number', order.tracking_number)
    order.delivery_notes = request.form.get('delivery_notes', order.delivery_notes)
    
    # Handle COD specific updates
    if order.payment_method == 'cod':
        order.delivery_attempted = request.form.get('delivery_attempted') == 'on'
        if request.form.get('generate_new_otp'):
            order.cod_otp = generate_cod_otp()
            if order.user.phone:
                send_cod_otp_sms(order.user.phone, order.cod_otp)
                flash(f'New COD OTP sent to customer: {order.cod_otp}', 'info')
    
    db.session.commit()
    flash('Order updated successfully!', 'success')
    
    return redirect(url_for('admin_orders'))

from sqlalchemy.orm import joinedload

@app.route('/admin/inventory')
@login_required
def admin_inventory():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))

    q = Product.query.options(joinedload(Product.inventory), joinedload(Product.category))

    search = request.args.get('search', '').strip()
    status = request.args.get('status', '').strip()          # 'active' | 'inactive' | ''
    category_id = request.args.get('category_id', '').strip()

    if search:
        q = q.filter(Product.name.ilike(f'%{search}%'))
    if status == 'active':
        q = q.filter(Product.is_active.is_(True))
    elif status == 'inactive':
        q = q.filter(Product.is_active.is_(False))
    if category_id:
        q = q.filter(Product.category_id == int(category_id))

    products = q.all()

    low_stock_count = sum(1 for p in products if 0 < p.get_total_stock() <= 10)
    out_stock_count = sum(1 for p in products if p.get_total_stock() == 0)

    return render_template('admin/inventory.html',
                           products=products,
                           low_stock_count=low_stock_count,
                           out_stock_count=out_stock_count)


@app.route('/admin/add_product', methods=['POST'])
@login_required
def admin_add_product():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))

    try:
        name = request.form.get('name')
        description = request.form.get('description')
        category_id = request.form.get('category_id')
        price = float(request.form.get('price') or 0)
        discount = float(request.form.get('discount') or 0)

        # Create new product
        new_product = Product(
            name=name,
            description=description,
            category_id=category_id,
            price=price,
            discount=discount
        )
        db.session.add(new_product)
        db.session.flush()  # Get product ID before commit

        # Handle sizes & stock
        sizes = request.form.getlist('sizes[]')
        stocks = request.form.getlist('stocks[]')
        for size, stock in zip(sizes, stocks):
            inventory_entry = Inventory(
                product_id=new_product.id,
                size=size,
                stock=int(stock or 0)
            )
            db.session.add(inventory_entry)

        # Handle product images
        if 'images' in request.files:
            for img in request.files.getlist('images'):
                if img and img.filename:
                    filename = secure_filename(img.filename)
                    img.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    image_entry = ProductImage(
                        product_id=new_product.id,
                        image_url=filename
                    )
                    db.session.add(image_entry)

        db.session.commit()
        flash('Product added successfully!', 'success')

    except Exception as e:
        db.session.rollback()
        flash(f'Error adding product: {str(e)}', 'danger')

    # Redirect back to the referring page (Dashboard or Inventory)
    referrer = request.referrer or url_for('admin_dashboard')
    return redirect(referrer)

@app.route('/admin/edit_product/<int:product_id>', methods=['POST'])
@login_required
def admin_edit_product(product_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))

    try:
        product = Product.query.get_or_404(product_id)
        
        # Update product fields
        product.name = request.form.get('name')
        product.description = request.form.get('description')
        product.category_id = request.form.get('category_id')
        product.price = float(request.form.get('price') or 0)
        product.discount = float(request.form.get('discount') or 0)

        # Update stock for each size
        for inventory_item in product.inventory:
            stock_field = f"stock_{inventory_item.id}"
            if stock_field in request.form:
                inventory_item.stock = int(request.form.get(stock_field) or 0)

        # Update images if provided
        if 'images' in request.files:
            for img in request.files.getlist('images'):
                if img and img.filename:
                    filename = secure_filename(img.filename)
                    img.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    new_img = ProductImage(product_id=product.id, image_url=filename)
                    db.session.add(new_img)

        db.session.commit()
        flash('Product updated successfully!', 'success')

    except Exception as e:
        db.session.rollback()
        flash(f'Error updating product: {str(e)}', 'danger')

    return redirect(url_for('admin_inventory'))


@app.route('/admin/update_stock/<int:product_id>', methods=['POST'])
@login_required
def admin_update_stock(product_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))

    try:
        # Get product
        product = Product.query.get_or_404(product_id)

        # Loop through sizes & update stock
        for inventory_item in product.inventory:
            field_name = f"stock_{inventory_item.id}"
            if field_name in request.form:
                new_stock = request.form.get(field_name, type=int)
                inventory_item.stock = new_stock if new_stock is not None else 0

        db.session.commit()
        flash('Stock updated successfully!', 'success')

    except Exception as e:
        db.session.rollback()
        flash(f'Error updating stock: {str(e)}', 'danger')

    return redirect(url_for('admin_inventory'))


@app.route('/admin/analytics')
@login_required
def admin_analytics():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Monthly sales data
    monthly_sales = db.session.query(
        extract('month', Order.created_at).label('month'),
        func.sum(Order.total_amount).label('revenue')
    ).filter(
        Order.payment_status == 'completed',
        extract('year', Order.created_at) == datetime.now().year
    ).group_by(extract('month', Order.created_at)).all()
    
    # Top selling products
    top_products = db.session.query(
        Product.name,
        func.sum(OrderItem.quantity).label('total_sold')
    ).join(OrderItem).join(Order).filter(
        Order.payment_status == 'completed'
    ).group_by(Product.name).order_by(func.sum(OrderItem.quantity).desc()).limit(10).all()
    
    return render_template('admin/analytics.html', 
                         monthly_sales=monthly_sales, 
                         top_products=top_products)

@app.route('/admin/discounts')
@login_required
def admin_discounts():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    discounts = Discount.query.order_by(Discount.created_at.desc()).all()
    return render_template('admin/discounts.html', discounts=discounts)

@app.route('/admin/discounts/add', methods=['POST'])
@login_required
def admin_add_discount():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('admin_discounts'))

    discount = Discount()
    discount.code = request.form['code'].upper()
    discount.discount_type = request.form['discount_type']
    discount.description = request.form.get('description')
    discount.discount_value = float(request.form['discount_value'])
    discount.max_discount = request.form.get('max_discount') or None
    discount.min_order_amount = float(request.form.get('min_order_amount') or 0)
    discount.usage_limit = request.form.get('usage_limit') or None
    discount.valid_from = datetime.strptime(request.form['valid_from'], '%Y-%m-%dT%H:%M')
    valid_until = request.form.get('valid_until')
    discount.valid_until = datetime.strptime(valid_until, '%Y-%m-%dT%H:%M') if valid_until else None
    discount.is_active = 'is_active' in request.form
    discount.used_count = 0

    db.session.add(discount)
    db.session.commit()
    flash('Discount created successfully', 'success')
    return redirect(url_for('admin_discounts'))


@app.route('/admin/discounts/edit/<int:discount_id>', methods=['POST'])
@login_required
def admin_edit_discount(discount_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('admin_discounts'))

    discount = Discount.query.get_or_404(discount_id)
    discount.code = request.form['code'].upper()
    discount.discount_type = request.form['discount_type']
    discount.description = request.form.get('description')
    discount.discount_value = float(request.form['discount_value'])
    discount.max_discount = request.form.get('max_discount') or None
    discount.min_order_amount = float(request.form.get('min_order_amount') or 0)
    discount.usage_limit = request.form.get('usage_limit') or None
    valid_until = request.form.get('valid_until')
    discount.valid_until = datetime.strptime(valid_until, '%Y-%m-%dT%H:%M') if valid_until else None
    discount.is_active = 'is_active' in request.form

    db.session.commit()
    flash('Discount updated successfully', 'success')
    return redirect(url_for('admin_discounts'))


@app.route('/admin/discounts/toggle/<int:discount_id>', methods=['POST'])
@login_required
def admin_toggle_discount(discount_id):
    if not current_user.is_admin:
        return jsonify({'status': 'error', 'message': 'Access denied'}), 403

    discount = Discount.query.get_or_404(discount_id)
    discount.is_active = not discount.is_active
    db.session.commit()
    return jsonify({'status': 'success', 'is_active': discount.is_active})



@app.route('/admin/returns')
@login_required
def admin_returns():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    returns = Return.query.order_by(Return.created_at.desc()).all()
    exchanges = Exchange.query.order_by(Exchange.created_at.desc()).all()
    
    return render_template('admin/returns.html', returns=returns, exchanges=exchanges)

@app.route('/admin/feedback')
@login_required
def admin_feedback():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    feedback_items = Feedback.query.order_by(Feedback.created_at.desc()).all()
    
    return render_template('admin/feedback.html', feedback_items=feedback_items)

@app.route('/admin/feedback/<int:feedback_id>/respond', methods=['POST'])
@login_required
def admin_respond_feedback(feedback_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    feedback_item = Feedback.query.get_or_404(feedback_id)
    feedback_item.admin_response = request.form.get('admin_response')
    feedback_item.is_approved = request.form.get('is_approved') == 'on'
    
    db.session.commit()
    flash('Feedback updated successfully!', 'success')
    
    return redirect(url_for('admin_feedback'))

@app.route('/admin/export/<data_type>')
@login_required
def admin_export_data(data_type):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    try:
        filename = export_data_to_excel(data_type)
        flash(f'Data exported successfully: {filename}', 'success')
    except Exception as e:
        flash(f'Export failed: {str(e)}', 'danger')
    
    if data_type == 'order_status':
        return redirect(url_for('admin_order_status'))
    elif data_type == 'discounts':
        return redirect(url_for('admin_discounts'))
    return redirect(url_for('admin_dashboard'))

# Comment and like routes
@app.route('/add_comment/<int:product_id>', methods=['POST'])
@login_required
def add_comment(product_id):
    content = request.form.get('content')
    if content:
        comment = Comment()
        comment.user_id = current_user.id
        comment.product_id = product_id
        comment.content = content
        db.session.add(comment)
        db.session.commit()
        flash('Comment added', 'success')
    
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/toggle_like/<int:product_id>')
@login_required
def toggle_like(product_id):
    like = Like.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    
    if like:
        db.session.delete(like)
        action = 'removed'
    else:
        like = Like()
        like.user_id = current_user.id
        like.product_id = product_id
        db.session.add(like)
        action = 'added'
    
    db.session.commit()
    flash(f'Like {action}', 'info')
    return redirect(url_for('product_detail', product_id=product_id))

# Return and exchange routes
@app.route('/request_return/<int:order_id>', methods=['POST'])
@login_required
def request_return(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('profile'))
    
    if not can_return_order(order):
        flash('Return period has expired or order is not eligible for return', 'warning')
        return redirect(url_for('profile'))
    
    reason = request.form.get('reason')
    description = request.form.get('description')
    
    return_request = Return()
    return_request.order_id = order_id
    return_request.user_id = current_user.id
    return_request.reason = reason
    return_request.description = description
    
    db.session.add(return_request)
    db.session.commit()
    
    flash('Return request submitted successfully', 'success')
    return redirect(url_for('profile'))

@app.route('/request_exchange/<int:order_id>', methods=['POST'])
@login_required
def request_exchange(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('profile'))
    
    reason = request.form.get('reason')
    description = request.form.get('description')
    new_size = request.form.get('new_size')
    
    exchange_request = Exchange()
    exchange_request.order_id = order_id
    exchange_request.user_id = current_user.id
    exchange_request.reason = reason
    exchange_request.description = description
    exchange_request.new_size = new_size
    
    db.session.add(exchange_request)
    db.session.commit()
    
    flash('Exchange request submitted successfully', 'success')
    return redirect(url_for('profile'))
